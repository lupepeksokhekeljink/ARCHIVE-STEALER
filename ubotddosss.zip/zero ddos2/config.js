module.exports = {
    apiId: 32559546,
    apiHash: "e053885248c398bd3f8ac7ab49bbc589",
    sessionFile: "session.json"
};
