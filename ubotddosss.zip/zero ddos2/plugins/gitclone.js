 /*  
 */
 
const fetch = require("node-fetch"); // Pastikan sudah install: npm install node-fetch@2

// ID kamu (biar hanya kamu yang bisa pakai, opsional)
const allowedId = 7818441356;

module.exports = {
  command: ["gitclone"],
  run: async ({ client, message, text, reply }) => {
    if (parseInt(message.senderId) !== allowedId) return;

    const args = text.trim().split(/\s+/);
    if (!args[0]) {
      return reply(
        "📦 Contoh penggunaan:\n`gitclone https://github.com/username/repo`",
        { parse_mode: "Markdown" }
      );
    }

    const urlText = args[0];
    const regex = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/([^\/\s]+)/i;

    if (!regex.test(urlText)) {
      return reply("❌ Link GitHub tidak valid.");
    }

    try {
      const [, user, rawRepo] = urlText.match(regex);
      const repo = rawRepo.replace(/\.git$/, "");
      const zipUrl = `https://api.github.com/repos/${user}/${repo}/zipball`;

      const headRes = await fetch(zipUrl, { method: "HEAD" });
      if (!headRes.ok) throw new Error("Repository tidak ditemukan");

      const fileName = `Export Rizztzy (${repo}).zip`;

      await client.sendFile(message.chatId, {
        file: zipUrl,
        filename: fileName,
        caption: `📁 Berhasil meng-clone repository *${user}/${repo}*`,
        parse_mode: "Markdown",
        replyTo: message.id,
      });

    } catch (err) {
      console.error("[GitClone Error]", err.message);
      return reply("❌ Terjadi kesalahan atau repository tidak ditemukan.");
    }
  },
};