const { pinterest, pinterest2, remini, mediafire, tiktokDl } = require('../utils/scraper');
const allowedId = 7818441356;

module.exports = {
  command: ["mediafire"],
  run: async ({ client, message, reply }) => {
    if (parseInt(message.senderId) !== allowedId) return;

    const text = message.message?.split(" ").slice(1).join(" ").trim();
    if (!text) {
      return reply("❗ Contoh penggunaan:\nmediafire https://www.mediafire.com/file/...", {
        parseMode: "html",
      });
    }

    if (!/^https?:\/\/(www\.)?mediafire\.com/i.test(text)) {
      return reply("❌ Link tautan tidak valid!");
    }

    try {
      const res = await mediafire(text);
      if (!res.link) return reply("❌ Gagal mendapatkan hasil dari MediaFire.");

      await client.sendFile(message.chatId, {
        file: res.link,
        fileName: "Export Rizztzy.zip",
        mimeType: "application/zip",
        replyTo: message.id,
      });
    } catch (e) {
      console.error("Mediafire Error:", e);
      return reply("❌ Terjadi kesalahan saat mengunduh file dari MediaFire.");
    }
  },
};