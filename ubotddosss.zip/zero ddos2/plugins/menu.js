 /*  
 */
 
const os = require("os");
const { formatSize } = require("../utils/fungsion");
const { performance } = require("perf_hooks");

const totalMem = os.totalmem();
const freeMem = os.freemem();
const usedMem = totalMem - freeMem;
const formattedUsedMem = formatSize(usedMem);
const formattedTotalMem = formatSize(totalMem);

function formatRuntime(ms) {
  let seconds = Math.floor(ms / 1000) % 60;
  let minutes = Math.floor(ms / (1000 * 60)) % 60;
  let hours = Math.floor(ms / (1000 * 60 * 60)) % 24;
  let days = Math.floor(ms / (1000 * 60 * 60 * 24));
  return `${days}d ${hours}h ${minutes}m ${seconds}s`;
}

let botStartTime = performance.now();

// ID kamu
const allowedId = 7818441356;

module.exports = {
  command: ["menu"],
  run: async ({ client, message, reply }) => {
    if (parseInt(message.senderId) !== allowedId) return;

    const user = await client.getEntity(message.senderId);
    const username = user.username ? `@${user.username}` : "";
    const fullName = user.firstName + (user.lastName ? ` ${user.lastName}` : "");
    const mention = username || fullName;
    const userId = user.id;
    const runtime = formatRuntime(performance.now() - botStartTime);

    const caption = `<blockquote>
┏━━━━━━ ( Informations ) ━━━━━━⭓
┃  𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐝 : @kingZero77
┃  𝐍𝐚𝐦𝐞 : ubotzeroddos
┃  𝐔𝐬𝐞𝐫 :  ${userId} 
┃  𝐕𝐞𝐫𝐬𝐢𝐨𝐧 : 1.0
┃  𝐑𝐮𝐧𝐓𝐢𝐦𝐞 : ${runtime}
┗━━━━━━━━━━━━━━━━━━━━━⭓
┏━━━━━  【 (!)𝐀͢𝐋͡𝐋 ⍣ 𝐌͢𝐄͡𝐍͜𝐔 】 ━━━━ ⊱ 
┃❍ gitclone
┃❍ gemini
┃❍ mediafire
┃❍ id
┃❍ subfinder
┃❍ trackip
┃❍ done
┃❍ proses
┃❍ githubstalk
┃❍ ttstalk
┃❍ ping
┃❍ reportch
┃❍ methods [ddos]
╰═━━━━━━━━━━━━━━━━━━━━⊱
</blockquote>`;


    await client.sendFile(message.chatId, {
      file: "https://files.catbox.moe/w3ygir.mp4",
      caption: caption,
      parseMode: "html",
      replyTo: message.id,
    });
  },
};