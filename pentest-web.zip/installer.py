#!/usr/bin/env python3
import os
import sys
import subprocess
from colorama import Fore, Style, init

init(autoreset=True)

def create_module_structure():
    """Create all 32 module files"""
    
    modules = {
        "sql_injection": {
            "description": "SQL Injection Scanner with advanced detection",
            "methods": ["scan_sql_injection", "blind_sql_test", "time_based_test"],
            "payload_file": "sqli.txt"
        },
        "xss_scanner": {
            "description": "XSS Scanner for Reflected, Stored, and DOM XSS",
            "methods": ["scan_reflected", "scan_stored", "scan_dom", "generate_payloads"],
            "payload_file": "xss.txt"
        },
        "command_injection": {
            "description": "Command Injection Detection",
            "methods": ["test_command_injection", "os_detection", "payload_generation"],
            "payload_file": "command_injection.txt"
        },
        "rce_scanner": {
            "description": "Remote Code Execution Scanner",
            "methods": ["scan_rce", "test_deserialization", "check_file_uploads"],
            "payload_file": "rce.txt"
        },
        "lfi_scanner": {
            "description": "Local File Inclusion Scanner",
            "methods": ["test_lfi", "path_traversal", "wrapper_abuse"],
            "payload_file": "lfi.txt"
        },
        # ... continue for all 32
    }
    
    # Create modules directory
    os.makedirs("modules", exist_ok=True)
    
    for module_name, info in modules.items():
        create_module_file(module_name, info)
    
    print(f"{Fore.GREEN}[+] Created {len(modules)} scanner modules{Style.RESET_ALL}")

def create_module_file(module_name, info):
    """Create individual module file"""
    
    class_name = module_name.title().replace("_", "")
    
    template = f'''#!/usr/bin/env python3
"""
{info['description']}
"""

import requests
import sys
from colorama import Fore, Style
from utils import ScannerBase, save_results, load_payloads

class {class_name}(ScannerBase):
    def __init__(self):
        super().__init__()
        self.module_name = "{module_name}"
        self.vulnerabilities = []
        self.payloads = load_payloads("{info.get('payload_file', 'generic.txt')}")
    
    def scan(self, target):
        """Main scanning function"""
        self.log(f"Starting {info['description']} scan on {{target}}", "INFO")
        
        # Run all scan methods
        for method_name in {info['methods']}:
            if hasattr(self, method_name):
                try:
                    getattr(self, method_name)(target)
                except Exception as e:
                    self.log(f"Method {{method_name}} failed: {{e}}", "ERROR")
        
        return self.vulnerabilities
    
    def check_vulnerability(self, target):
        """Check for {module_name.replace('_', ' ').title()}"""
        try:
            # Implement specific vulnerability check
            test_url = f"{{target}}/?test=payload"
            response = self.make_request(test_url)
            
            if response and response.status_code == 200:
                # Add detection logic here
                pass
                
        except Exception as e:
            self.log(f"Error: {{e}}", "ERROR")
    
    # Add specific methods here
    def example_method(self, target):
        """Example method template"""
        self.log(f"Testing {{target}}", "INFO")

def main():
    scanner = {class_name}()
    
    if len(sys.argv) > 1:
        target = sys.argv[1]
    else:
        target = input("Enter target URL: ").strip()
    
    if not target.startswith(('http://', 'https://')):
        target = 'http://' + target
    
    print(f"{Fore.CYAN}\\n[+] Starting {info['description']}{Style.RESET_ALL}")
    print(f"{Fore.YELLOW}[+] Target: {{target}}{Style.RESET_ALL}")
    
    results = scanner.scan(target)
    
    if results:
        print(f"{Fore.GREEN}\\n[+] Found {{len(results)}} vulnerabilities!{Style.RESET_ALL}")
        for vuln in results:
            severity = vuln.get('severity', 'Medium')
            color = Fore.RED if severity in ['Critical', 'High'] else Fore.YELLOW
            print(f"{{color}}[{{severity}}] {{vuln.get('description', 'N/A')}}{{Style.RESET_ALL}}")
        
        # Save results
        filename = save_results(results, scanner.module_name)
        print(f"{Fore.CYAN}[+] Results saved to {{filename}}{Style.RESET_ALL}")
    else:
        print(f"{Fore.RED}[-] No vulnerabilities found{Style.RESET_ALL}")

if __name__ == "__main__":
    main()
'''
    
    with open(f"modules/{module_name}.py", 'w') as f:
        f.write(template)

def create_payload_files():
    """Create payload files for each vulnerability type"""
    
    payloads_dir = "payloads"
    os.makedirs(payloads_dir, exist_ok=True)
    
    # SQL Injection payloads
    sqli_payloads = [
        "' OR '1'='1",
        "' UNION SELECT NULL--",
        "' AND 1=CONVERT(int, @@version)--",
        "1' ORDER BY 1--",
        "1' UNION SELECT database()--",
        # ... add more
    ]
    
    with open(f"{payloads_dir}/sqli.txt", 'w') as f:
        f.write("\n".join(sqli_payloads))
    
    # XSS payloads
    xss_payloads = [
        "<script>alert('XSS')</script>",
        "<img src=x onerror=alert(1)>",
        "\" onmouseover=\"alert(1)",
        "<svg onload=alert(1)>",
        # ... add more
    ]
    
    with open(f"{payloads_dir}/xss.txt", 'w') as f:
        f.write("\n".join(xss_payloads))
    
    print(f"{Fore.GREEN}[+] Created payload files{Style.RESET_ALL}")

def install_dependencies():
    """Install required Python packages"""
    
    requirements = [
        "requests",
        "colorama",
        "beautifulsoup4",
        "lxml",
        "dnspython",
        "pycryptodome",
        "urllib3",
    ]
    
    print(f"{Fore.CYAN}[+] Installing dependencies...{Style.RESET_ALL}")
    
    for package in requirements:
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", package])
            print(f"{Fore.GREEN}[✓] {package}{Style.RESET_ALL}")
        except:
            print(f"{Fore.RED}[✗] Failed to install {package}{Style.RESET_ALL}")
    
    print(f"{Fore.GREEN}[+] Dependencies installed{Style.RESET_ALL}")

def main():
    print(f"{Fore.CYAN}╔══════════════════════════════════════════════════╗")
    print(f"║     32-IN-1 WEB PENTEST FRAMEWORK INSTALLER      ║")
    print(f"╚══════════════════════════════════════════════════╝{Style.RESET_ALL}")
    
    # Install dependencies
    install_dependencies()
    
    # Create directory structure
    os.makedirs("modules", exist_ok=True)
    os.makedirs("payloads", exist_ok=True)
    os.makedirs("results", exist_ok=True)
    
    # Create all modules
    create_module_structure()
    
    # Create payload files
    create_payload_files()
    
    # Make main executable
    os.chmod("main.py", 0o755)
    
    print(f"{Fore.CYAN}\\n{'='*50}{Style.RESET_ALL}")
    print(f"{Fore.GREEN}[+] INSTALLATION COMPLETE!{Style.RESET_ALL}")
    print(f"{Fore.YELLOW}[+] To run: python3 main.py{Style.RESET_ALL}")
    print(f"{Fore.YELLOW}[+] Or: ./main.py{Style.RESET_ALL}")
    print(f"{Fore.CYAN}[+] 32 Scanner modules ready to use!{Style.RESET_ALL}")
    print(f"{Fore.CYAN}{'='*50}{Style.RESET_ALL}")

if __name__ == "__main__":
    main()
