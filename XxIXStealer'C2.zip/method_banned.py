#!/usr/bin/env python3
# METHOD BANNED V2.0 - STABLE VERSION
# BY AMBYAR

import os
import sys
import time
import json
import random
import requests
import threading
import subprocess
from datetime import datetime
from colorama import init, Fore, Style

# ========== INISIALISASI ==========
init(autoreset=True)
os.system('cls' if os.name == 'nt' else 'clear')

# ========== KONFIGURASI ==========
CONFIG = {
    'telegram_token': "8534634507:AAEwI0cCFiylAVGwwTo30DxS0kDgqGvgzxQ",
    'telegram_chat_id': "8334915741",
    'dana_qris': "https://link.dana.id/minta?full_url=https://qr.dana.id/v1/281012092025122562828811",
    'harga': 50000,
    'admin_telegram': "@MethodBannedAdmin",
    'channel': "@BannedMethodsID"
}

# ========== CLASS TELEGRAM NOTIFY ==========
class TelegramNotifier:
    def __init__(self):
        self.token = CONFIG['telegram_token']
        self.chat_id = CONFIG['telegram_chat_id']
        self.base_url = f"https://api.telegram.org/bot{self.token}"
        self.session_id = f"SESS-{random.randint(10000, 99999)}"
    
    def send_message(self, text):
        try:
            url = f"{self.base_url}/sendMessage"
            payload = {
                "chat_id": self.chat_id,
                "text": text,
                "parse_mode": "HTML"
            }
            response = requests.post(url, json=payload, timeout=5)
            return response.status_code == 200
        except:
            return False
    
    def notify_start(self):
        message = f"""
🚀 <b>SCRIPT METHOD BANNED DIMULAI</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━━
🆔 <b>Session:</b> <code>{self.session_id}</code>
⏰ <b>Waktu:</b> {datetime.now().strftime("%H:%M:%S")}
📅 <b>Tanggal:</b> {datetime.now().strftime("%d/%m/%Y")}
━━━━━━━━━━━━━━━━━━━━━━━━━━━
        """
        return self.send_message(message)
    
    def notify_target(self, target_id, platform, method):
        message = f"""
🎯 <b>TARGET DIPILIH</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━━
🆔 <b>Session:</b> <code>{self.session_id}</code>
🎯 <b>Target:</b> <code>{target_id}</code>
📱 <b>Platform:</b> {platform}
⚡ <b>Method:</b> {method}
━━━━━━━━━━━━━━━━━━━━━━━━━━━
        """
        return self.send_message(message)
    
    def notify_result(self, target_id, success, method):
        status = "✅ BERHASIL" if success else "❌ GAGAL"
        message = f"""
🏁 <b>HASIL EKSEKUSI</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎯 <b>Target:</b> <code>{target_id}</code>
⚡ <b>Method:</b> {method}
📊 <b>Status:</b> {status}
⏰ <b>Waktu:</b> {datetime.now().strftime("%H:%M:%S")}
━━━━━━━━━━━━━━━━━━━━━━━━━━━
        """
        return self.send_message(message)

# ========== BANNER ==========
def show_banner():
    banner = f"""
{Fore.RED}╔══════════════════════════════════════════════════════════════╗
{Fore.RED}║                                                              ║
{Fore.RED}║  ███╗   ███╗███████╗████████╗██╗  ██╗ ██████╗ ██████╗       ║
{Fore.RED}║  ████╗ ████║██╔════╝╚══██╔══╝██║  ██║██╔═══██╗██╔══██╗      ║
{Fore.RED}║  ██╔████╔██║█████╗     ██║   ███████║██║   ██║██║  ██║      ║
{Fore.RED}║  ██║╚██╔╝██║██╔══╝     ██║   ██╔══██║██║   ██║██║  ██║      ║
{Fore.RED}║  ██║ ╚═╝ ██║███████╗   ██║   ██║  ██║╚██████╔╝██████╔╝      ║
{Fore.RED}║  ╚═╝     ╚═╝╚══════╝   ╚═╝   ╚═╝  ╚═╝ ╚═════╝ ╚═════╝       ║
{Fore.RED}║                                                              ║
{Fore.RED}╠══════════════════════════════════════════════════════════════╣
{Fore.RED}║                    METHOD BANNED V2.0                        ║
{Fore.RED}║               🔥 STABLE VERSION - BY AMBYAR                  ║
{Fore.RED}╚══════════════════════════════════════════════════════════════╝

{Fore.YELLOW}════════════════════════════════════════════════════════════════
{Fore.CYAN}💰 HARGA: Rp {CONFIG['harga']:,}
{Fore.CYAN}📱 METODE: QRIS DANA
{Fore.CYAN}👤 ADMIN: {CONFIG['admin_telegram']}
{Fore.CYAN}📢 CHANNEL: {CONFIG['channel']}
{Fore.YELLOW}════════════════════════════════════════════════════════════════
    """
    print(banner)

# ========== MENU UTAMA ==========
def show_main_menu():
    print(f"\n{Fore.GREEN}[ MENU UTAMA ]")
    print(f"{Fore.YELLOW}══════════════════════════════════════")
    print(f"{Fore.CYAN}[1] {Fore.WHITE}Pilih Target & Eksekusi")
    print(f"{Fore.CYAN}[2] {Fore.WHITE}Informasi Pembayaran")
    print(f"{Fore.CYAN}[3] {Fore.WHITE}Test Koneksi")
    print(f"{Fore.CYAN}[4] {Fore.WHITE}Keluar")
    print(f"{Fore.YELLOW}══════════════════════════════════════")

# ========== MENU TARGET ==========
def show_target_menu():
    targets = [
        {"id": 1, "name": "📱 WhatsApp", "input": "Nomor WhatsApp (+62): "},
        {"id": 2, "name": "📸 Instagram", "input": "Username Instagram (@): "},
        {"id": 3, "name": "📘 Facebook", "input": "URL/ID Facebook: "},
        {"id": 4, "name": "🎵 TikTok", "input": "Username TikTok (@): "},
        {"id": 5, "name": "✈️ Telegram", "input": "Username Telegram (@): "},
        {"id": 6, "name": "🎮 Mobile Legends", "input": "ID Game ML: "},
        {"id": 7, "name": "💀 Multi Platform", "input": "ID Target: "}
    ]
    
    print(f"\n{Fore.GREEN}[ PILIH TARGET ]")
    print(f"{Fore.YELLOW}══════════════════════════════════════")
    for target in targets:
        print(f"{Fore.CYAN}[{target['id']}] {Fore.WHITE}{target['name']}")
    print(f"{Fore.YELLOW}══════════════════════════════════════")
    
    return targets

# ========== MENU METHOD ==========
def show_method_menu():
    methods = {
        "A": {"name": "MASS REPORT", "rate": 95, "time": "30-60s"},
        "B": {"name": "CONTENT INJECTION", "rate": 90, "time": "45-90s"},
        "C": {"name": "API EXPLOIT", "rate": 85, "time": "60-120s"},
        "D": {"name": "SYSTEM FLAG BOT", "rate": 98, "time": "30-45s"},
        "E": {"name": "ULTIMATE COMBO", "rate": 99, "time": "90-180s"}
    }
    
    print(f"\n{Fore.GREEN}[ PILIH METODE ]")
    print(f"{Fore.YELLOW}══════════════════════════════════════")
    for code, method in methods.items():
        print(f"{Fore.CYAN}[{code}] {Fore.WHITE}{method['name']}")
        print(f"     {Fore.YELLOW}Success: {method['rate']}% | Time: {method['time']}")
    print(f"{Fore.YELLOW}══════════════════════════════════════")
    
    return methods

# ========== PAYMENT INFO ==========
def show_payment_info():
    print(f"\n{Fore.GREEN}[ INFORMASI PEMBAYARAN ]")
    print(f"{Fore.YELLOW}══════════════════════════════════════")
    print(f"{Fore.CYAN}💰 HARGA: {Fore.WHITE}Rp {CONFIG['harga']:,}")
    print(f"{Fore.CYAN}📱 METODE: {Fore.WHITE}QRIS DANA")
    print(f"{Fore.CYAN}🔗 LINK: {Fore.WHITE}{CONFIG['dana_qris']}")
    print(f"\n{Fore.YELLOW}📋 CARA BAYAR:")
    print(f"{Fore.WHITE}1. Buka DANA/OVO/GoPay/ShopeePay")
    print(f"{Fore.WHITE}2. Pilih 'Scan QRIS'")
    print(f"{Fore.WHITE}3. Scan kode QR di bawah")
    print(f"{Fore.WHITE}4. Bayar Rp {CONFIG['harga']:,}")
    print(f"{Fore.WHITE}5. Screenshot bukti transfer")
    print(f"{Fore.WHITE}6. Kirim ke admin: {CONFIG['admin_telegram']}")
    
    # Simulate QR Code
    print(f"\n{Fore.CYAN}[ QR CODE ]")
    print(f"{Fore.WHITE}╔══════════════════════════════════════╗")
    print(f"{Fore.WHITE}║                                      ║")
    print(f"{Fore.WHITE}║  ██████████████████████████████████  ║")
    print(f"{Fore.WHITE}║  ██  METHOD BANNED V2.0 - AMBYAR  ██  ║")
    print(f"{Fore.WHITE}║  ██        Rp {CONFIG['harga']:,}         ██  ║")
    print(f"{Fore.WHITE}║  ██████████████████████████████████  ║")
    print(f"{Fore.WHITE}║                                      ║")
    print(f"{Fore.WHITE}╚══════════════════════════════════════╝")
    
    input(f"\n{Fore.GREEN}Tekan Enter untuk kembali ke menu...")

# ========== VERIFY PAYMENT ==========
def verify_payment():
    print(f"\n{Fore.GREEN}[ VERIFIKASI PEMBAYARAN ]")
    print(f"{Fore.YELLOW}══════════════════════════════════════")
    print(f"{Fore.WHITE}Kirim bukti transfer ke admin:")
    print(f"{Fore.CYAN}Telegram: {Fore.WHITE}{CONFIG['admin_telegram']}")
    print(f"\n{Fore.YELLOW}⏳ Menunggu konfirmasi admin...")
    
    for i in range(3, 0, -1):
        print(f"{Fore.CYAN}    {i}...")
        time.sleep(1)
    
    activation_code = f"ACT-{random.randint(10000, 99999)}"
    print(f"\n{Fore.GREEN}✅ AKTIVASI BERHASIL!")
    print(f"{Fore.CYAN}Kode Aktivasi: {Fore.WHITE}{activation_code}")
    print(f"{Fore.CYAN}Berlaku hingga: {Fore.WHITE}{datetime.now().strftime('%d/%m/%Y %H:%M')}")
    
    return activation_code

# ========== EXECUTION ENGINE ==========
class ExecutionEngine:
    def __init__(self, notifier):
        self.notifier = notifier
        self.target_id = ""
        self.platform = ""
        self.method = ""
    
    def select_target(self):
        targets = show_target_menu()
        
        while True:
            try:
                choice = int(input(f"\n{Fore.GREEN}Pilih target (1-7): {Fore.WHITE}"))
                if 1 <= choice <= 7:
                    selected = targets[choice-1]
                    self.platform = selected['name']
                    
                    self.target_id = input(f"\n{Fore.CYAN}{selected['input']}{Fore.WHITE}")
                    
                    if choice == 1 and not self.target_id.startswith("62"):
                        self.target_id = "62" + self.target_id.lstrip("0")
                    
                    return True
                else:
                    print(f"{Fore.RED}Pilihan tidak valid!")
            except ValueError:
                print(f"{Fore.RED}Masukkan angka!")
    
    def select_method(self):
        methods = show_method_menu()
        
        while True:
            choice = input(f"\n{Fore.GREEN}Pilih metode (A-E): {Fore.WHITE}").upper()
            if choice in methods:
                self.method = methods[choice]['name']
                return True
            else:
                print(f"{Fore.RED}Metode tidak valid!")
    
    def execute(self):
        print(f"\n{Fore.RED}[ MEMULAI EKSEKUSI ]")
        print(f"{Fore.YELLOW}══════════════════════════════════════")
        
        # Notify start
        self.notifier.notify_target(self.target_id, self.platform, self.method)
        
        # Show target info
        print(f"{Fore.CYAN}🎯 Target: {Fore.WHITE}{self.target_id}")
        print(f"{Fore.CYAN}📱 Platform: {Fore.WHITE}{self.platform}")
        print(f"{Fore.CYAN}⚡ Method: {Fore.WHITE}{self.method}")
        print(f"{Fore.YELLOW}══════════════════════════════════════")
        
        # Simulate execution
        steps = [
            "Menginisialisasi sistem...",
            "Menyiapkan payload...",
            "Membuat koneksi API...",
            "Mengirim laporan massal...",
            "Menyuntikkan konten pelanggaran...",
            "Menjalankan bot flag...",
            "Mengeksploitasi kerentanan...",
            "Memverifikasi hasil...",
            "Membersihkan jejak..."
        ]
        
        for i, step in enumerate(steps, 1):
            progress = (i / len(steps)) * 100
            bar = "█" * int(progress / 100 * 40) + "░" * (40 - int(progress / 100 * 40))
            
            print(f"\r{Fore.CYAN}[{i:02d}/{len(steps):02d}] {step}")
            print(f"{Fore.YELLOW}Progress: [{bar}] {progress:.1f}%")
            
            time.sleep(random.uniform(0.5, 1.5))
        
        # Determine success (based on method)
        success_rates = {
            "MASS REPORT": 95,
            "CONTENT INJECTION": 90,
            "API EXPLOIT": 85,
            "SYSTEM FLAG BOT": 98,
            "ULTIMATE COMBO": 99
        }
        
        success_chance = success_rates.get(self.method, 50)
        success = random.random() * 100 <= success_chance
        
        # Show result
        print(f"\n{Fore.YELLOW}══════════════════════════════════════")
        if success:
            print(f"{Fore.GREEN}✅ BANNED BERHASIL!")
            print(f"{Fore.WHITE}Target {self.target_id} telah di-BANNED permanen.")
        else:
            print(f"{Fore.YELLOW}⚠️  BANNED GAGAL!")
            print(f"{Fore.WHITE}Target masih aktif. Coba metode lain.")
        
        # Notify result
        self.notifier.notify_result(self.target_id, success, self.method)
        
        return success

# ========== TEST CONNECTION ==========
def test_connection():
    print(f"\n{Fore.GREEN}[ TEST KONEKSI ]")
    print(f"{Fore.YELLOW}══════════════════════════════════════")
    
    tests = [
        ("Internet", "8.8.8.8"),
        ("Telegram API", "api.telegram.org"),
        ("WhatsApp", "web.whatsapp.com"),
        ("Instagram", "instagram.com")
    ]
    
    for name, host in tests:
        try:
            if os.name == 'nt':
                response = os.system(f"ping -n 1 {host} > nul")
            else:
                response = os.system(f"ping -c 1 {host} > /dev/null 2>&1")
            
            if response == 0:
                print(f"{Fore.GREEN}✅ {name}: {Fore.WHITE}Connected")
            else:
                print(f"{Fore.YELLOW}⚠️  {name}: {Fore.WHITE}Slow")
        except:
            print(f"{Fore.RED}❌ {name}: {Fore.WHITE}Failed")
        
        time.sleep(0.5)
    
    print(f"{Fore.YELLOW}══════════════════════════════════════")
    input(f"\n{Fore.GREEN}Tekan Enter untuk melanjutkan...")

# ========== MAIN FUNCTION ==========
def main():
    # Initialize
    notifier = TelegramNotifier()
    engine = ExecutionEngine(notifier)
    
    # Show banner
    show_banner()
    
    # Send start notification
    notifier.notify_start()
    
    # Check activation
    activated = False
    activation_code = ""
    
    while True:
        show_main_menu()
        
        try:
            choice = input(f"\n{Fore.GREEN}Pilih menu (1-4): {Fore.WHITE}")
            
            if choice == "1":
                if not activated:
                    print(f"\n{Fore.YELLOW}⚠️  Script belum diaktifkan!")
                    print(f"{Fore.WHITE}Silakan lakukan pembayaran terlebih dahulu.")
                    
                    activate = input(f"\n{Fore.GREEN}Aktifkan sekarang? (y/n): {Fore.WHITE}").lower()
                    if activate == 'y':
                        show_payment_info()
                        activation_code = verify_payment()
                        if activation_code:
                            activated = True
                            print(f"\n{Fore.GREEN}✅ Script aktif! Kode: {activation_code}")
                    continue
                
                # Execute banned
                if engine.select_target():
                    if engine.select_method():
                        engine.execute()
                        
                        # Ask for continue
                        cont = input(f"\n{Fore.GREEN}Eksekusi target lain? (y/n): {Fore.WHITE}").lower()
                        if cont != 'y':
                            continue
            
            elif choice == "2":
                show_payment_info()
            
            elif choice == "3":
                test_connection()
            
            elif choice == "4":
                print(f"\n{Fore.GREEN}👋 Terima kasih telah menggunakan Method Banned V2.0")
                print(f"{Fore.CYAN}Channel: {Fore.WHITE}{CONFIG['channel']}")
                time.sleep(2)
                break
            
            else:
                print(f"{Fore.RED}Pilihan tidak valid!")
        
        except KeyboardInterrupt:
            print(f"\n\n{Fore.YELLOW}⚠️  Script dihentikan oleh pengguna")
            break
        except Exception as e:
            print(f"\n{Fore.RED}❌ Error: {str(e)}")
            print(f"{Fore.YELLOW}⚠️  Melanjutkan ke menu utama...")
            time.sleep(2)

# ========== RUN SCRIPT ==========
if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n\n{Fore.RED}Script dihentikan")
        sys.exit(0)
    except Exception as e:
        print(f"\n{Fore.RED}Fatal Error: {str(e)}")
        input(f"\n{Fore.YELLOW}Tekan Enter untuk keluar...")
        sys.exit(1)
